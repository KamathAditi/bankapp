package com.bank;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void testLoginWithValidCredentials() throws Exception {
        Map<String, String> loginData = Map.of(
                "email", "customer2@example.com",
                "password", "Password@123"
        );

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(loginData)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").exists());
    }

    @Test
    void testLoginWithInvalidCredentials() throws Exception {
        Map<String, String> loginData = Map.of(
                "email", "johndoe@example.com",
                "password", "Password@0123"
        );

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(loginData)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testLoginWithUnregisteredEmail() throws Exception {
        Map<String, String> loginData = Map.of(
                "email", "johndoeee@example.com",
                "password", "Password@0123"
        );

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(loginData)))
                .andExpect(status().isBadRequest()); // or isNotFound(), depending on implementation
    }

    @Test
    void testRegisterNewCustomer() throws Exception {
        Map<String, Object> payload = Map.of(
                "fullName", "John Doe",
                "contactNumber", "9876543210",
                "dateOfBirth", "1990-05-15",
                "login", Map.of("email", "customer212@example.com", "password", "Password@123"),
                "addresses", List.of(
                        Map.of("doorNumber", "12A", "streetName", "Main Street", "city", "New York", "state", "NY", "pincode", "100017"),
                        Map.of("doorNumber", "22B", "streetName", "Second Avenue", "city", "Los Angeles", "state", "CA", "pincode", "900201")
                )
        );

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(payload)))
                .andExpect(status().isOk());
    }

    @Test
    void testRegisterWithExistingEmail() throws Exception {
        Map<String, Object> payload = Map.of(
                "fullName", "John Doe",
                "contactNumber", "9876543210",
                "dateOfBirth", "1990-05-15",
                "login", Map.of("email", "johndoe2@example.com", "password", "Password@123"),
                "addresses", List.of(
                        Map.of("doorNumber", "12A", "streetName", "Main Street", "city", "New York", "state", "NY", "pincode", "100017")
                )
        );

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(payload)))
                .andExpect(status().isBadRequest()); // or appropriate error code
    }

    @Test
    void testRegisterWithoutAddress() throws Exception {
        Map<String, Object> payload = Map.of(
                "fullName", "John Doe",
                "contactNumber", "9876543210",
                "dateOfBirth", "1990-05-15",
                "login", Map.of("email", "johndoe3@example.com", "password", "Password@123"),
                "addresses", List.of()
        );

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(payload)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testRegisterWithInvalidPhone() throws Exception {
        Map<String, Object> payload = Map.of(
                "fullName", "John Doe",
                "contactNumber", "98763210",  // Invalid
                "dateOfBirth", "1990-05-15",
                "login", Map.of("email", "johndoe4@example.com", "password", "Password@123"),
                "addresses", List.of(
                        Map.of("doorNumber", "12A", "streetName", "Main Street", "city", "New York", "state", "NY", "pincode", "100017")
                )
        );

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(payload)))
                .andExpect(status().isBadRequest());
    }
}

