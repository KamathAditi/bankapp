package com.bank.service;

import com.bank.dto.AccountResponseDTO;
import com.bank.dto.TransactionRequestDTO;
import com.bank.dto.TransactionResponseDTO;
import com.bank.entity.Account;
import com.bank.entity.Transaction;
import com.bank.exception.*;
import com.bank.mapper.TransactionMapper;
import com.bank.repository.AccountRepository;
import com.bank.repository.TransactionRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Objects;
import java.util.Random;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final static Random random = new Random();

    public TransactionServiceImpl(AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }


    @Override
    @Transactional
    public String deposit(Double amount, Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        String type = "DEPOSIT";
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }

        if (account.getFrozen()) {
            return createTransaction(accountNumber,null, amount, "FAILED", type, "Account is frozen");
        }

        if (amount == null || amount <= 0) {
            throw new InvalidAmountException("Transfer amount must be greater than zero");
        }

        account.setBalance(account.getBalance() + amount);
        accountRepository.save(account);

        return createTransaction(accountNumber,null, amount, "SUCCESS", type, "Deposited " + amount + " successfully");
    }


    @Override
    public String withdraw(Double amount, Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        String type = "WITHDRAW";
        if (account == null) {
            throw new AccountNotFoundException("Account number " + accountNumber + " not found");
        }

        if (account.getFrozen()) {
            return createTransaction(accountNumber, null, amount, "FAILED", type, "Account is frozen");
        }

        if (amount == null || amount <= 0) {
            throw new InvalidAmountException("Transfer amount must be greater than zero");
        }

        if (amount > account.getBalance()) {
            return createTransaction(accountNumber,null, amount, "FAILED", type, " Amount must be less than " + account.getBalance());
        }

        account.setBalance(account.getBalance() - amount);
        accountRepository.save(account);

        return createTransaction(accountNumber,null, amount, "SUCCESS", type, "Withdrawn " + amount + " successfully");
    }

    private String createTransaction(Long accountNumber, Long receiverAccountNumber, double amount, String status, String type, String description) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        Account receiver = accountRepository.getAccountByAccountNumber(receiverAccountNumber);

        TransactionRequestDTO transactionRequestDTO = new TransactionRequestDTO();
        transactionRequestDTO.setTransactionId(generateNewTransactionId());
        transactionRequestDTO.setTransactionType(type);
        transactionRequestDTO.setSenderAccountNumber(accountNumber);
        transactionRequestDTO.setAmount(amount);
        transactionRequestDTO.setStatus(status);
        transactionRequestDTO.setDescription(description);
        transactionRequestDTO.setReceiverAccountNumber(receiverAccountNumber);
        if(type.equals("TRANSFER")) {
            transactionRequestDTO.setAccount(receiver);
        }
        else{
            transactionRequestDTO.setAccount(account);
        }
        Transaction transaction = TransactionMapper.transactionToModel(transactionRequestDTO);
        transactionRepository.save(transaction);
        if(status.equals("SUCCESS")) {
            return status;
        }
        throw new TransactionFailedException("Transaction "+transaction.getTransactionId()+" failed. " + transaction.getDescription());

    }

    private Long generateNewTransactionId() {
        Long transactionId;
        do{
            long min = 100_000_000_000L;
            long max = 999_999_999_999L;

            transactionId = min + ((long) (random.nextDouble() * (max - min)));
        }while(transactionRepository.existsByTransactionId(transactionId));
        return transactionId;
    }

    @Override
    public String transferAmount(Double amount, Long senderAccountNumber, Long receiverAccountNumber) {
        final String type = "TRANSFER";

        // Validate input parameters
        if (amount == null || amount <= 0) {
            throw new InvalidAmountException("Transfer amount must be greater than zero");
        }

        if (senderAccountNumber == null || receiverAccountNumber == null) {
            throw new IllegalArgumentException("Account numbers cannot be null");
        }

        if (senderAccountNumber.equals(receiverAccountNumber)) {
            throw new IllegalArgumentException("Sender account cannot be the same as receiver account");
        }

        // Fetch accounts
        Account senderAccount = accountRepository.getAccountByAccountNumber(senderAccountNumber);
        Account receiverAccount = accountRepository.getAccountByAccountNumber(receiverAccountNumber);

        // Validate accounts exist
        if (senderAccount == null) {
            throw new AccountNotFoundException("Account number " + senderAccountNumber + " not found");
        }

        if (receiverAccount == null) {
            throw new AccountNotFoundException("Account number " + receiverAccountNumber + " not found");
        }

        // Check account status
        if (senderAccount.getFrozen()) {
            return createTransaction(senderAccountNumber, receiverAccountNumber, amount, "FAILED", type,
                    "Transfer failed: Sender account is frozen");
        }

        if (receiverAccount.getFrozen()) {
            return createTransaction(senderAccountNumber, receiverAccountNumber, amount, "FAILED", type,
                    "Transfer failed: Receiver account is frozen");
        }

        // Check sufficient funds
        if (senderAccount.getBalance() < amount) {
            return createTransaction(senderAccountNumber, receiverAccountNumber, amount, "FAILED", type,
                    "Transfer failed: Insufficient funds. Available balance: " +
                            String.format("%.2f", senderAccount.getBalance()));
        }

        try {
            // Perform the transfer
            senderAccount.setBalance(senderAccount.getBalance() - amount);
            receiverAccount.setBalance(receiverAccount.getBalance() + amount);

            // Save updated accounts
            accountRepository.save(senderAccount);
            accountRepository.save(receiverAccount);

            // Create transaction records

            return createTransaction(senderAccountNumber, receiverAccountNumber, amount, "SUCCESS", type,
                    "Transfer of " + String.format("%.2f", amount) + " completed successfully");
        } catch (Exception e) {
            // Log the exception
            // Create a failed transaction record
            return createTransaction(senderAccountNumber, receiverAccountNumber, amount, "FAILED", type,
                    "Transfer failed due to system error");
        }
    }

    @Override
    public List<TransactionResponseDTO> getTransactionsByAccountNumber(Long accountNumber) {

        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        if(account == null) {
            throw new AccountNotFoundException("Account number " + accountNumber + " not found");
        }

        List<Transaction> transactions = transactionRepository.findAllByAccountNumber(accountNumber);
        if (transactions.isEmpty()) {
            throw new TransactionsNotFoundException("Transactions not Found");
        }
        return transactions.stream().map(TransactionMapper::transactionToDto).toList();
    }

    @Override
    public List<TransactionResponseDTO> getTransactonsBetweenDates(Long accountNumber,LocalDate startDate, LocalDate endDate) {

        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        if(account == null) {
            throw new AccountNotFoundException("Account number " + accountNumber + " not found");
        }

        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(LocalTime.MAX);

        if (!startDateTime.isBefore(endDateTime)) {
            throw new DateTimeException("Start date must be before end date");
        }

        List<Transaction> transactions = transactionRepository.findAllByAccountAndTimestampBetween(accountNumber, startDateTime, endDateTime);
        if(transactions.isEmpty()) {
            throw new TransactionsNotFoundException("No transactions between " + startDate + " and " + endDate);
        }
        return transactions.stream().map(TransactionMapper::transactionToDto).toList();
    }
}
