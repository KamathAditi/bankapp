package com.bank.service;

import com.bank.dto.AccountRequestDTO;
import com.bank.dto.AccountResponseDTO;
import com.bank.dto.AccountStatementDto;
import com.bank.dto.CustomerResponseDTO;
import com.bank.entity.Account;
import com.bank.entity.Customer;
import com.bank.entity.Transaction;
import com.bank.exception.AccountNotFoundException;
import com.bank.exception.CustomerNotFoundException;
import com.bank.mapper.AccountMapper;
import com.bank.mapper.AccountStatementMapper;
import com.bank.mapper.CustomerMapper;
import com.bank.repository.AccountRepository;
import com.bank.repository.CustomerRepository;
import com.bank.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;


@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final CustomerRepository customerRepository;
    private final static Random random = new Random();
    private final TransactionRepository transactionRepository;
    LocalDateTime now = LocalDateTime.now();

    public AccountServiceImpl(AccountRepository accountRepository, CustomerRepository customerRepository, TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.customerRepository = customerRepository;
        this.transactionRepository = transactionRepository;
    }

    @Override
    public AccountResponseDTO addAccount(AccountRequestDTO accountRequestDTO) {
        Customer customer = customerRepository.findById(accountRequestDTO.getCustomerId())
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + accountRequestDTO.getCustomerId()));
        accountRequestDTO.setAccountNumber(generateUniqueAccountNumber());
        Account account = accountRepository.save(AccountMapper.accountToModel(accountRequestDTO, customer));
        return AccountMapper.accountToDTO(account);
    }

    public  Long generateUniqueAccountNumber() {
        Long accountNumber;
        do{
            long min = 10_000_000L;
            long max = 999_999_999_999L;

            // Generate a random long in the range [min, max]
            accountNumber =  min + ((long) (random.nextDouble() * (max - min)));
        }while(accountRepository.existsByAccountNumber(accountNumber));
        return accountNumber;
    }

    @Override
    public AccountResponseDTO getAccountByAccountNumber(Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account not found with Account Number: " + accountNumber);
        }
        return AccountMapper.accountToDTO(account);
    }

    @Override
    public AccountResponseDTO updateAccount(AccountRequestDTO accountRequestDTO) {
        Account account = accountRepository.getAccountByAccountNumber(accountRequestDTO.getAccountNumber());
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }
        return AccountMapper.accountToDTO(accountRepository.save(account));
    }

    @Override
    public void deleteAccount(Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }
        accountRepository.delete(account);
    }

    @Override
    public List<AccountResponseDTO> getAllAccounts() {
        List<Account> accounts = accountRepository.findAll();
        if (accounts.isEmpty()) {
            throw new AccountNotFoundException("Accounts not found");
        }
        return accounts.stream().map(AccountMapper::accountToDTO).toList();
    }

    @Override
    public List<AccountResponseDTO> getAccountsByCustomerId(Long customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not found with Id: " + customerId));
        List<Account> accounts = accountRepository.findByCustomer_CustomerIdOrderByCreatedAt(customerId);
        return accounts.stream().map(AccountMapper::accountToDTO).toList();
    }

    @Override
    public Double getAccountBalance(Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }
        return account.getBalance();
    }

    @Override
    public Boolean verifyAccountExist(Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        return account != null;
    }

    @Override
    public String freezeAccount(Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }
        if (account.getFrozen()){
            return "Account is already frozen";
        }
        account.setFrozen(true);
        accountRepository.save(account);
        return "Account frozen";
    }

    @Override
    public String unfreezeAccount(Long accountNumber) {
        Account account = accountRepository.getAccountByAccountNumber(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }

        if (!account.getFrozen()){
            return "Account is not frozen";
        }

        account.setFrozen(false);
        accountRepository.save(account);
        return "Account unfrozen";
    }

    @Override
    public CustomerResponseDTO getCustomerDetails(Long accountNumber) {
        Customer customer = customerRepository.findByAccounts_AccountNumber(accountNumber);
        if (customer == null) {
            throw new CustomerNotFoundException("Customer not found");
        }
        return CustomerMapper.customerToDTO(customer);
    }

    @Override
    public AccountStatementDto getAccountStatement(Long customerId) {
        // Fetch customer and accounts
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new CustomerNotFoundException("Customer Not found with Id: " + customerId));

        List<Account> accounts = accountRepository.findByCustomer_CustomerIdOrderByCreatedAt(customerId);
        if (accounts.isEmpty()) {
            throw new AccountNotFoundException("No accounts found for customer ID " + customerId);
        }

        List<Long> accountNumbers = accounts.stream()
                .map(Account::getAccountNumber)
                .collect(Collectors.toList());

        // Fetch transactions for all accounts
        List<Transaction> transactions = transactionRepository.findByAccountNumbers(accountNumbers);

        // Initialize totals
        BigDecimal income = BigDecimal.ZERO;
        BigDecimal expense = BigDecimal.ZERO;
        BigDecimal daily = BigDecimal.ZERO;
        BigDecimal weekly = BigDecimal.ZERO;
        BigDecimal monthly = BigDecimal.ZERO;

        // Get the current date and time for calculating periods (daily, weekly, monthly)
        LocalDateTime now = LocalDateTime.now();

        // Process each transaction
        for (Transaction tx : transactions) {
            boolean isIncome = accountNumbers.contains(tx.getSenderAccountNumber()) && tx.getStatus().equals("SUCCESS")
                    && (tx.getTransactionType().equals("DEPOSIT") || tx.getTransactionType().equals("TRANSFER"));

            boolean isExpense = accountNumbers.contains(tx.getSenderAccountNumber()) && tx.getStatus().equals("SUCCESS")
                    && (tx.getTransactionType().equals("WITHDRAW") ||
                    (tx.getTransactionType().equals("TRANSFER") && !tx.getAccount().getAccountNumber().equals(tx.getSenderAccountNumber())));

            // Handle different transaction types
            if (tx.getStatus().equals("SUCCESS")) {
                // Deposit (Income)
                if (tx.getTransactionType().equals("DEPOSIT") && isIncome) {
                    income = income.add(BigDecimal.valueOf(tx.getAmount()));
                }

                // Withdraw (Expense)
                if (tx.getTransactionType().equals("WITHDRAW") && isExpense) {
                    expense = expense.add(BigDecimal.valueOf(tx.getAmount()));
                }

                // Transfer (Income or Expense)
                if (tx.getTransactionType().equals("TRANSFER")) {
                    if (isIncome) {
                        income = income.add(BigDecimal.valueOf(tx.getAmount()));
                    } else if (isExpense) {
                        expense = expense.add(BigDecimal.valueOf(tx.getAmount()));
                    }
                }

                // Update daily, weekly, monthly totals based on transaction timestamp
                if (tx.getTimeStamp().toLocalDate().equals(now.toLocalDate())) {
                    daily = daily.add(BigDecimal.valueOf(tx.getAmount()));
                }
                if (tx.getTimeStamp().toLocalDate().isAfter(now.minusWeeks(1).toLocalDate())) {
                    weekly = weekly.add(BigDecimal.valueOf(tx.getAmount()));
                }
                if (tx.getTimeStamp().toLocalDate().isAfter(now.minusMonths(1).toLocalDate())) {
                    monthly = monthly.add(BigDecimal.valueOf(tx.getAmount()));
                }
            }
        }

        // Calculate total cash flow
        BigDecimal totalCashFlow = income.subtract(expense);

        // Map to DTO and return
        return AccountStatementMapper.toDto(daily, weekly, monthly, income, expense, totalCashFlow);
    }
}
