package com.bank.service;

import com.bank.dto.CustomerRequestDTO;
import com.bank.dto.CustomerResponseDTO;
import com.bank.dto.LoginRequestDTO;
import com.bank.entity.Customer;
import com.bank.entity.Login;
import com.bank.exception.CustomerNotFoundException;
import com.bank.exception.EmailAlreadyExistsException;
import com.bank.exception.EmailNotFoundException;
import com.bank.exception.InvalidCredentialsException;
import com.bank.mapper.CustomerMapper;
import com.bank.repository.CustomerRepository;
import com.bank.repository.LoginRepository;
import com.bank.security.JwtService;
import jakarta.transaction.Transactional;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class AuthServiceImpl implements AuthService {
    private final LoginRepository loginRepository;
    private final CustomerRepository customerRepository;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;


    public AuthServiceImpl(LoginRepository loginRepository, CustomerRepository customerRepository, AuthenticationManager authenticationManager, JwtService jwtService) {
        this.loginRepository = loginRepository;
        this.customerRepository = customerRepository;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    public String refreshToken(String token) {
        return "";
    }

    public String authenticate(LoginRequestDTO loginRequest) {

        if (!loginRepository.existsByEmail(loginRequest.getEmail())) {
            throw new EmailNotFoundException("Email not registered: "+ loginRequest.getEmail());
        }
        Login login = loginRepository.findByEmail(loginRequest.getEmail()).orElseThrow(() -> new CustomerNotFoundException("There is no customer with email : " + loginRequest.getEmail()));
        loginRequest.setRole(login.getRole());
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword(), List.of(new SimpleGrantedAuthority("ROLE_" + loginRequest.getRole())))
            );

            if (authentication.isAuthenticated()) {
                return jwtService.generateToken(loginRequest);
            }

        } catch (AuthenticationException e) {
            throw new InvalidCredentialsException("Entered email or password is incorrect");
        }
        return "Failed";
    }

    @Transactional
    public CustomerResponseDTO registerCustomer(CustomerRequestDTO customerRequestDTO) {
        if(loginRepository.existsByEmail(customerRequestDTO.getLogin().getEmail())){
            throw new EmailAlreadyExistsException("The customer has already been registered with the email "+customerRequestDTO.getLogin().getEmail());
        }
        String role = "CUSTOMER";
        Customer newCustomer = customerRepository.save(CustomerMapper.customerToModel(customerRequestDTO, role));
        return CustomerMapper.customerToDTO(newCustomer);
    }
}
