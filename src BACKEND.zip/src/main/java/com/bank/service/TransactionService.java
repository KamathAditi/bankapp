package com.bank.service;

import com.bank.dto.TransactionResponseDTO;

import java.time.LocalDate;
import java.util.List;

public interface TransactionService {
    String deposit(Double amount, Long accountNumber);
    String withdraw(Double amount, Long accountNumber);
    String transferAmount(Double amount, Long senderAccountNumber, Long receiverAccountNumber);
    List<TransactionResponseDTO> getTransactionsByAccountNumber(Long accountNumber);
    List<TransactionResponseDTO> getTransactonsBetweenDates(Long accountNumber,LocalDate startDate, LocalDate endDate);
}
