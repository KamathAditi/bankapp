package com.bank.service;

import com.bank.dto.CustomerRequestDTO;
import com.bank.dto.CustomerResponseDTO;
import com.bank.dto.LoginRequestDTO;
import com.bank.dto.LoginResponseDTO;

public interface AuthService {
    CustomerResponseDTO registerCustomer(CustomerRequestDTO customerRequestDTO);
    String authenticate(LoginRequestDTO loginRequest);
}
