package com.bank.service;

import com.bank.dto.AddressResponseDTO;
import com.bank.dto.CustomerRequestDTO;
import com.bank.dto.CustomerResponseDTO;
import com.bank.entity.Address;
import com.bank.entity.Customer;
import com.bank.entity.Login;
import com.bank.exception.AddressNotFoundException;
import com.bank.exception.CustomerNotFoundException;
import com.bank.exception.EmailAlreadyExistsException;
import com.bank.mapper.CustomerMapper;
import com.bank.repository.AddressRepository;
import com.bank.repository.CustomerRepository;
import com.bank.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;


@Service("customerService")
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final AddressRepository addressRepository;
    private final LoginRepository loginRepository;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository, AddressRepository addressRepository, LoginRepository loginRepository) {
        this.customerRepository = customerRepository;
        this.addressRepository = addressRepository;

        this.loginRepository = loginRepository;
    }

    @Override
    public CustomerResponseDTO addAdmin(CustomerRequestDTO customerRequestDTO) {
        if(loginRepository.existsByEmail(customerRequestDTO.getLogin().getEmail())){
            throw new EmailAlreadyExistsException("User already been registered with the email "+customerRequestDTO.getLogin().getEmail());
        }
        String role = "ADMIN";
        Customer newCustomer = customerRepository.save(CustomerMapper.customerToModel(customerRequestDTO, role));
        return CustomerMapper.customerToDTO(newCustomer);
    }

    @Override
    public List<CustomerResponseDTO> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        return customers.stream().map(CustomerMapper::customerToDTO).toList();
    }

    @Override
    public CustomerResponseDTO updateCustomer(Long customerId, CustomerRequestDTO customerRequestDTO) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not found with Id: " + customerId));
        customer.setFullName(customerRequestDTO.getFullName());
        customer.setContactNumber(customerRequestDTO.getContactNumber());
        customer.setDateOfBirth(customerRequestDTO.getDateOfBirth());

        Customer updatedCustomer = customerRepository.save(customer);
        return CustomerMapper.customerToDTO(updatedCustomer);
    }

    @Override
    public CustomerResponseDTO updateCustomerName(Long customerId, String customerName) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not found with Id: " + customerId));
        customer.setFullName(customerName);
        Customer updatedCustomer = customerRepository.save(customer);
        return CustomerMapper.customerToDTO(updatedCustomer);
    }

    @Override
    public CustomerResponseDTO updateCustomerAddress(Long customerId, Long addressId, AddressResponseDTO address) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not found with Id: " + customerId));
        Address addressToUpdate = addressRepository.findById(addressId).orElseThrow(()-> new AddressNotFoundException("Address not available"));
        if(!addressToUpdate.getCustomer().getCustomerId().equals(customer.getCustomerId())) {
            throw new AddressNotFoundException("Address does not belong to Customer with Id: " + customer.getCustomerId());
        }

        addressToUpdate.setDoorNumber(address.getDoorNumber());
        addressToUpdate.setCity(address.getCity());
        addressToUpdate.setState(address.getState());
        addressToUpdate.setPincode(Integer.parseInt(address.getPincode()));
        addressToUpdate.setStreetName(address.getStreetName());

        addressRepository.save(addressToUpdate);
        customerRepository.save(customer);
        return CustomerMapper.customerToDTO(customer);
    }

    @Override
    public CustomerResponseDTO updateCustomerDob(Long customerId, LocalDate dob) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not found with Id: " + customerId));
        customer.setDateOfBirth(dob);
        Customer updatedCustomer = customerRepository.save(customer);
        return CustomerMapper.customerToDTO(updatedCustomer);
    }

    @Override
    public List<CustomerResponseDTO> getCustomerByName(String firstName) {
        List<Customer> customers = customerRepository.findByFullNameLike(firstName);
        return customers.stream().map(CustomerMapper::customerToDTO).toList();
    }

    @Override
    public List<CustomerResponseDTO> getCustomerByDob(LocalDate dob) {
        List<Customer> customers = customerRepository.findByDateOfBirth(dob);
        return customers.stream().map(CustomerMapper::customerToDTO).toList();
    }

    @Override
    public CustomerResponseDTO getCustomerByEmail(String email) {
        Login login = loginRepository.findByEmail(email)
                .orElseThrow(() -> new CustomerNotFoundException("There is no customer with email : " + email));
        Customer customer = login.getCustomer();
        return CustomerMapper.customerToDTO(customer);
    }

    @Override
    public CustomerResponseDTO getCustomerById(Long customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not found with Id: " + customerId));
        return CustomerMapper.customerToDTO(customer);
    }

    @Override
    public void deleteCustomer(Long customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not found with Id: " + customerId));
        customerRepository.delete(customer);
    }

}
