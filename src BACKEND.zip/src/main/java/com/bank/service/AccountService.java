package com.bank.service;

import com.bank.dto.AccountRequestDTO;
import com.bank.dto.AccountResponseDTO;
import com.bank.dto.AccountStatementDto;
import com.bank.dto.CustomerResponseDTO;

import java.util.List;

public interface AccountService {
    AccountResponseDTO addAccount(AccountRequestDTO accountRequestDTO);
    AccountResponseDTO getAccountByAccountNumber(Long accountNumber);
    AccountResponseDTO updateAccount(AccountRequestDTO account);
    void deleteAccount(Long accountNumber);
    List<AccountResponseDTO> getAllAccounts();
    List<AccountResponseDTO> getAccountsByCustomerId(Long customerId);
    Double getAccountBalance(Long accountNumber);
    Boolean verifyAccountExist(Long accountNumber);
    String freezeAccount(Long accountNumber);
    String unfreezeAccount(Long accountNumber);
    CustomerResponseDTO getCustomerDetails(Long accountNumber);
    AccountStatementDto getAccountStatement(Long customerId);
}
