package com.bank.service;

import com.bank.dto.AddressResponseDTO;
import com.bank.dto.CustomerRequestDTO;
import com.bank.dto.CustomerResponseDTO;

import java.time.LocalDate;
import java.util.List;


public interface CustomerService {

    CustomerResponseDTO addAdmin(CustomerRequestDTO customerRequestDTO);
    List<CustomerResponseDTO> getAllCustomers();

    CustomerResponseDTO updateCustomer(Long customerId, CustomerRequestDTO customerRequestDTO);
    CustomerResponseDTO updateCustomerName(Long customerId,String customerName);
    CustomerResponseDTO updateCustomerAddress(Long customerId, Long addressId, AddressResponseDTO address);
    CustomerResponseDTO updateCustomerDob(Long customerId, LocalDate dob);

    List<CustomerResponseDTO> getCustomerByName(String firstName);
    List<CustomerResponseDTO> getCustomerByDob(LocalDate dob);

    CustomerResponseDTO getCustomerByEmail(String email);
    CustomerResponseDTO getCustomerById(Long customerId) throws Exception;
    void deleteCustomer(Long customerId) throws Exception;
    //Add in other methods

}
