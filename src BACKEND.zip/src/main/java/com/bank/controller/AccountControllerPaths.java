package com.bank.controller;

public class AccountControllerPaths {

    public static final String BASE_URL = "/accounts";

    // Account specific paths
    public static final String ADD_ACCOUNT = BASE_URL;
    public static final String GET_ACCOUNT = BASE_URL + "/{accountNumber}";
    public static final String GET_ALL_ACCOUNTS = BASE_URL;
    public static final String GET_ACCOUNT_BY_CUSTOMER_ID = BASE_URL + "/getAccountByCustomerId/{customerId}";
    public static final String UPDATE_ACCOUNT = BASE_URL;
    public static final String DELETE_ACCOUNT = BASE_URL + "/{accountNumber}";
    public static final String GET_BALANCE = BASE_URL + "/{accountNumber}/balance";
    public static final String EXISTS_ACCOUNT = BASE_URL + "/exists/{accountNumber}";
    public static final String FREEZE_ACCOUNT = BASE_URL + "/{accountNumber}/freeze";
    public static final String UNFREEZE_ACCOUNT = BASE_URL + "/{accountNumber}/unfreeze";
    public static final String GET_ACCOUNT_HOLDER = BASE_URL + "/{accountNumber}/holder";
    public static final String GET_STATEMENT = BASE_URL + "/statement/{customerId}";


}
