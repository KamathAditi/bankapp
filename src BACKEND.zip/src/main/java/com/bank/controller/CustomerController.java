package com.bank.controller;

import com.bank.dto.AddressResponseDTO;
import com.bank.dto.CustomerRequestDTO;
import com.bank.dto.CustomerResponseDTO;
import com.bank.exception.BadRequest;
import com.bank.service.CustomerService;
import jakarta.validation.Valid;
import org.apache.coyote.BadRequestException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {

    private final CustomerService customerService;
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping(CustomerControllerPaths.ADD_ADMIN)
    public ResponseEntity<CustomerResponseDTO> addAdmin(@Valid @RequestBody CustomerRequestDTO customerRequestDTO) {
        CustomerResponseDTO customerResponseDTO = customerService.addAdmin(customerRequestDTO);
        return ResponseEntity.ok().body(customerResponseDTO);
    }

    @GetMapping(CustomerControllerPaths.GET_ALL_CUSTOMERS)
    public ResponseEntity<List<CustomerResponseDTO>> getAllCustomers() {
        List<CustomerResponseDTO> customers = customerService.getAllCustomers();
        return ResponseEntity.ok().body(customers);
    }

    @PutMapping(CustomerControllerPaths.UPDATE_CUSTOMER)
    public ResponseEntity<CustomerResponseDTO> updateCustomer(@Valid @PathVariable Long customerId, @RequestBody CustomerRequestDTO customerRequestDTO) {
        CustomerResponseDTO customerResponseDTO = customerService.updateCustomer(customerId, customerRequestDTO);
        return ResponseEntity.ok().body(customerResponseDTO);
    }

    @PatchMapping(CustomerControllerPaths.UPDATE_CUSTOMER_NAME)
    public ResponseEntity<CustomerResponseDTO> updateCustomerName(@Valid @PathVariable Long customerId, @RequestBody Map<String, String> requestBody) {
        String fullName = requestBody.get("fullName");
        if(fullName == null){
            throw new BadRequest("Full name is required");
        }
        CustomerResponseDTO customerResponseDTO = customerService.updateCustomerName(customerId, fullName);
        return ResponseEntity.ok().body(customerResponseDTO);
    }

    @PatchMapping(CustomerControllerPaths.UPDATE_CUSTOMER_DOB)
    public ResponseEntity<CustomerResponseDTO> updateCustomerDOB(@Valid @PathVariable Long customerId,  @RequestBody Map<String, String> requestBody) {
        CustomerResponseDTO customerResponseDTO = customerService.updateCustomerDob(customerId, LocalDate.parse(requestBody.get("dateOfBirth")));
        return ResponseEntity.ok().body(customerResponseDTO);
    }

    @PatchMapping(CustomerControllerPaths.UPDATE_CUSTOMER_ADDRESS)
    public ResponseEntity<CustomerResponseDTO> updateCustomerAddress(@Valid @PathVariable Long customerId, @PathVariable Long addressId, @RequestBody AddressResponseDTO addressDTO) {

        CustomerResponseDTO customerResponseDTO = customerService.updateCustomerAddress(customerId, addressId, addressDTO);
        return ResponseEntity.ok().body(customerResponseDTO);
    }

    @GetMapping(CustomerControllerPaths.GET_CUSTOMER_BY_ID)
    public ResponseEntity<CustomerResponseDTO> getCustomerById(@PathVariable Long id) throws Exception {
        CustomerResponseDTO customerResponseDTO = customerService.getCustomerById(id);
        return ResponseEntity.ok().body(customerResponseDTO);
    }

    @GetMapping(CustomerControllerPaths.GET_CUSTOMER_BY_NAME)
    public ResponseEntity<List<CustomerResponseDTO>> getCustomerByName(@PathVariable String name) {
        List<CustomerResponseDTO> customerResponseDTOList = customerService.getCustomerByName(name);
        return ResponseEntity.ok().body(customerResponseDTOList);
    }

    @GetMapping(CustomerControllerPaths.GET_CUSTOMER_BY_DOB)
    public ResponseEntity<List<CustomerResponseDTO>> getCustomerByDOB(@PathVariable String dob) {
        List<CustomerResponseDTO> customerResponseDTOList = customerService.getCustomerByDob(LocalDate.parse(dob));
        return ResponseEntity.ok().body(customerResponseDTOList);
    }

    @GetMapping(CustomerControllerPaths.GET_CUSTOMER_BY_EMAIL)
    public ResponseEntity<CustomerResponseDTO> getCustomerByEmail(@PathVariable String email) {
        CustomerResponseDTO customerResponseDTOList = customerService.getCustomerByEmail(email);
        return ResponseEntity.ok().body(customerResponseDTOList);
    }

    @DeleteMapping(CustomerControllerPaths.DELETE_CUSTOMER)
    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) throws Exception {
        customerService.deleteCustomer(id);
        return ResponseEntity.ok().build();
    }

    //must have a customer role
    @GetMapping(CustomerControllerPaths.GET_LOGGED_CUSTOMER)
    public ResponseEntity<CustomerResponseDTO> getLoggedInUser(Authentication authentication) {
        String email = authentication.getName();
        CustomerResponseDTO customer = customerService.getCustomerByEmail(email);
        return ResponseEntity.ok().body(customer);

    }
}
