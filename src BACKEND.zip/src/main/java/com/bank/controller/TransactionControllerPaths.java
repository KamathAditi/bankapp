package com.bank.controller;

public class TransactionControllerPaths {
    // Base URL for Accounts
    public static final String BASE_URL = "/accounts";

    // Transaction specific paths
    public static final String DEPOSIT = BASE_URL + "/{accountNumber}/deposit/{amount}";
    public static final String WITHDRAW = BASE_URL + "/{accountNumber}/withdraw/{amount}";
    public static final String TRANSFER = BASE_URL + "/{senderAccountNumber}/transfer/{receiverAccountNumber}/{amount}";
    public static final String GET_TRANSACTIONS = BASE_URL + "/{accountNumber}/transactions";
    public static final String GET_TRANSACTIONS_BETWEEN_DATES = BASE_URL + "/{accountNumber}/transactions/{startDate}/{endDate}";

}
