package com.bank.controller;

import com.bank.dto.CustomerRequestDTO;
import com.bank.dto.CustomerResponseDTO;
import com.bank.dto.LoginRequestDTO;
import com.bank.dto.LoginResponseDTO;
import com.bank.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LoginController {

    private final AuthService authService;

    public LoginController(AuthService authService) {
        this.authService = authService;
    }


    @PostMapping(LoginControllerPaths.REGISTER)
    public ResponseEntity<CustomerResponseDTO> register(@Valid @RequestBody CustomerRequestDTO customerRequestDTO) {
        CustomerResponseDTO customerResponseDTO = authService.registerCustomer(customerRequestDTO);
        return ResponseEntity.ok().body(customerResponseDTO);
    }
    @PostMapping(LoginControllerPaths.LOGIN)
    public ResponseEntity<Map<String, String>> login(@RequestBody LoginRequestDTO loginRequestDTO) {
        String token = authService.authenticate(loginRequestDTO);
        Map<String, String> response = new HashMap<>();
        response.put("token", token);
        return ResponseEntity.ok().body(response);
    }
}
