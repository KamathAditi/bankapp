package com.bank.controller;

public class CustomerControllerPaths {

    public static final String BASE_URL = "/customer";

    public static final String ADD_ADMIN = BASE_URL + "/addadmin";
    public static final String GET_ALL_CUSTOMERS = BASE_URL;
    public static final String UPDATE_CUSTOMER = BASE_URL + "/{customerId}";
    public static final String UPDATE_CUSTOMER_NAME = BASE_URL + "/{customerId}/name";
    public static final String UPDATE_CUSTOMER_DOB = BASE_URL + "/{customerId}/dob";
    public static final String UPDATE_CUSTOMER_ADDRESS = BASE_URL + "/{customerId}/{addressId}";
    public static final String GET_CUSTOMER_BY_ID = BASE_URL + "/{id}";
    public static final String GET_CUSTOMER_BY_NAME = BASE_URL + "/findbyname/{name}";
    public static final String GET_CUSTOMER_BY_DOB = BASE_URL + "/findbydob/{dob}";
    public static final String GET_CUSTOMER_BY_EMAIL = BASE_URL + "/findbyemail/{email}";
    public static final String DELETE_CUSTOMER = BASE_URL + "/{id}";
    public static final String GET_LOGGED_CUSTOMER = BASE_URL + "/me";

}
