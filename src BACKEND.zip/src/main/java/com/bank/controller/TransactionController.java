package com.bank.controller;

import com.bank.dto.TransactionResponseDTO;
import com.bank.service.TransactionService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }
    @PostMapping(TransactionControllerPaths.DEPOSIT)
    public ResponseEntity<Map<String, String>> depositToAccount(@PathVariable Long accountNumber, @PathVariable Double amount) {
        String response = transactionService.deposit(amount, accountNumber);
        Map<String, String> responseBody = new HashMap<>();
        responseBody.put("status", response);  // "SUCCESS" or "FAILED"
        return ResponseEntity.ok(responseBody);
    }

    @PostMapping(TransactionControllerPaths.WITHDRAW)
    public ResponseEntity<Map<String, String>> withdrawFromAccount(@PathVariable Long accountNumber, @PathVariable Double amount) {
        String response = transactionService.withdraw(amount, accountNumber);
        Map<String, String> responseBody = new HashMap<>();
        responseBody.put("status", response);  // "SUCCESS" or "FAILED"
        return ResponseEntity.ok(responseBody);
    }

    @PostMapping(TransactionControllerPaths.TRANSFER)
    public ResponseEntity<Map<String, String>> transferAmount(@PathVariable Long senderAccountNumber, @PathVariable Long receiverAccountNumber, @PathVariable Double amount) {
        String response = transactionService.transferAmount(amount, senderAccountNumber, receiverAccountNumber);
        Map<String, String> responseBody = new HashMap<>();
        responseBody.put("status", response);  // "SUCCESS" or "FAILED"
        return ResponseEntity.ok(responseBody);
    }
    @GetMapping(TransactionControllerPaths.GET_TRANSACTIONS)
    public ResponseEntity<List<TransactionResponseDTO>> getTransactions(@PathVariable Long accountNumber) {
        List<TransactionResponseDTO> transactionResponseDTOS = transactionService.getTransactionsByAccountNumber(accountNumber);
        return ResponseEntity.ok(transactionResponseDTOS);
    }

    @GetMapping(TransactionControllerPaths.GET_TRANSACTIONS_BETWEEN_DATES)
    public ResponseEntity<List<TransactionResponseDTO>> getTransactionBetweenDates(@PathVariable Long accountNumber, @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)  LocalDate startDate, @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)  LocalDate endDate) {
        List<TransactionResponseDTO> transactionResponseDTOS = transactionService.getTransactonsBetweenDates(accountNumber, startDate, endDate);
        return ResponseEntity.ok(transactionResponseDTOS);
    }

}
