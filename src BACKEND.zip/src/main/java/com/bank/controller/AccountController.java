package com.bank.controller;

import com.bank.dto.*;
import com.bank.mapper.AccountStatusMapper;
import com.bank.service.AccountService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @PostMapping(AccountControllerPaths.ADD_ACCOUNT)
    public ResponseEntity<AccountResponseDTO> addAccount(@Valid @RequestBody AccountRequestDTO accountRequestDTO) {
        AccountResponseDTO accountResponseDTO = accountService.addAccount(accountRequestDTO);
        return ResponseEntity.ok().body(accountResponseDTO);
    }

    @GetMapping(AccountControllerPaths.GET_ACCOUNT)
    public ResponseEntity<AccountResponseDTO> getAccount(@PathVariable Long accountNumber) {
        AccountResponseDTO accountResponseDTO = accountService.getAccountByAccountNumber(accountNumber);
        return ResponseEntity.ok().body(accountResponseDTO);
    }

    @GetMapping(AccountControllerPaths.GET_ALL_ACCOUNTS)
    public ResponseEntity<List<AccountResponseDTO>> getAllAccounts() {
        List<AccountResponseDTO> accountResponseDTO = accountService.getAllAccounts();
        return ResponseEntity.ok().body(accountResponseDTO);
    }

    @GetMapping(AccountControllerPaths.GET_ACCOUNT_BY_CUSTOMER_ID)
    public ResponseEntity<List<AccountResponseDTO>> getAccountByCustomerId(@PathVariable Long customerId) {
        List<AccountResponseDTO> accountResponseDTO = accountService.getAccountsByCustomerId(customerId);
        return ResponseEntity.ok().body(accountResponseDTO);
    }

    @PutMapping(AccountControllerPaths.UPDATE_ACCOUNT)
    public ResponseEntity<AccountResponseDTO> updateAccount(@Valid @RequestBody AccountRequestDTO accountRequestDTO) {
        AccountResponseDTO accountResponseDTO = accountService.updateAccount(accountRequestDTO);
        return ResponseEntity.ok().body(accountResponseDTO);
    }

    @DeleteMapping(AccountControllerPaths.DELETE_ACCOUNT)
    public ResponseEntity<Void> deleteAccount(@PathVariable Long accountNumber) {
        accountService.deleteAccount(accountNumber);
        return ResponseEntity.ok().build();
    }

    @GetMapping(AccountControllerPaths.GET_BALANCE)
    public ResponseEntity<Double> getBalance(@PathVariable Long accountNumber) {
        Double accountBalance = accountService.getAccountBalance(accountNumber);
        return ResponseEntity.ok().body(accountBalance);
    }

    @GetMapping(AccountControllerPaths.EXISTS_ACCOUNT)
    public ResponseEntity<Boolean> existsAccount(@PathVariable Long accountNumber) {
        Boolean accountExists = accountService.verifyAccountExist(accountNumber);
        return ResponseEntity.ok().body(accountExists);
    }

    @PostMapping(AccountControllerPaths.FREEZE_ACCOUNT)
    public ResponseEntity<AccountStatusResponse> freezeAccount(@PathVariable Long accountNumber) {
        String status = accountService.freezeAccount(accountNumber);
        AccountStatusResponse response = AccountStatusMapper.toResponse(accountNumber, status);
        return ResponseEntity.ok().body(response);
    }

    @PostMapping(AccountControllerPaths.UNFREEZE_ACCOUNT)
    public ResponseEntity<AccountStatusResponse> unfreezeAccount(@PathVariable Long accountNumber) {
        String status = accountService.unfreezeAccount(accountNumber);
        AccountStatusResponse response = AccountStatusMapper.toResponse(accountNumber, status);
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(AccountControllerPaths.GET_ACCOUNT_HOLDER)
    public ResponseEntity<CustomerResponseDTO> getCustomerByAccountNumber(@PathVariable Long accountNumber) {
        CustomerResponseDTO customerResponseDTO = accountService.getCustomerDetails(accountNumber);
        return ResponseEntity.ok().body(customerResponseDTO);
    }

    @GetMapping(AccountControllerPaths.GET_STATEMENT)
    public ResponseEntity<AccountStatementDto> getStatementByAccountNumber(@PathVariable Long customerId) {
        AccountStatementDto accountStatementDto = accountService.getAccountStatement(customerId);
        return ResponseEntity.ok().body(accountStatementDto);
    }
}
