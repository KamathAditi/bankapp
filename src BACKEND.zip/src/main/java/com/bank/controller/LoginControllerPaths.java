package com.bank.controller;

public class LoginControllerPaths {
    public static final String BASE_URL = "/auth";

    // Authentication specific paths
    public static final String REGISTER = BASE_URL + "/register";
    public static final String LOGIN = BASE_URL + "/login";
}
