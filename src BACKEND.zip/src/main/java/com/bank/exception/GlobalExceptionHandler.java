package com.bank.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.time.DateTimeException;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationException(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();

        ex.getBindingResult().getFieldErrors().forEach(
                error -> errors.put(error.getField(), error.getDefaultMessage()));
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<Map<String, String>> handleCustomerNotFoundException(CustomerNotFoundException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Customer Not Found");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(AddressNotFoundException.class)
    public ResponseEntity<Map<String, String>> handleAddressNotFoundException(AddressNotFoundException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Address Not Found");
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(EmailAlreadyExistsException.class)
    public ResponseEntity<Map<String, String>> handleEmailAlreadyExistsException(EmailAlreadyExistsException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Email Already Exists");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<Map<String, String>> handleAccountNotFoundException(AccountNotFoundException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Account Not Found");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(AccountFrozenException.class)
    public ResponseEntity<Map<String, String>> handleAccountFrozenException(AccountFrozenException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Account Frozen");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(TransactionsNotFoundException.class)
    public ResponseEntity<Map<String, String>> handleTransactionsNotFoundException(TransactionsNotFoundException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Transactions Not Found");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(EmailNotFoundException.class)
    public ResponseEntity<Map<String, String>> handleEmailNotFoundException(EmailNotFoundException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Email Not Found");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(InvalidCredentialsException.class)
    public ResponseEntity<Map<String, String>> handleInvalidCredentialsException(InvalidCredentialsException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Invalid Credentials");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }
    @ExceptionHandler(DateTimeException.class)
    public ResponseEntity<Map<String, String>> handleDateTimeException(DateTimeException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Date Time Error");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(InvalidAmountException.class)
    public ResponseEntity<Map<String, String>> handleInvalidAmountException(InvalidAmountException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Invalid Amount");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(TransactionFailedException.class)
    public ResponseEntity<Map<String, String>> handleTransactionFailedException(TransactionFailedException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Transaction Failed");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler(BadRequest.class)
    public ResponseEntity<Map<String, String>> handleBadRequest(BadRequest ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("message", "Bad Request");
        errors.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(errors);
    }
}
