package com.bank.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddressRequestDTO {

    @NotNull(message = "Door number cannot be null")
    @Size(min = 1, max = 10, message = "Door number should be between 1 and 10 characters")
    private String doorNumber;

    @NotNull(message = "Street name cannot be null")
    @Size(min = 3, max = 100, message = "Street name should be between 3 and 100 characters")
    private String streetName;

    @NotNull(message = "City cannot be null")
    @Size(min = 2, max = 50, message = "City name should be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "City name should only contain alphabetic characters and spaces")
    private String city;

    @NotNull(message = "State cannot be null")
    @Size(min = 2, max = 50, message = "State name should be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "State name should only contain alphabetic characters and spaces")
    private String state;

    @NotNull(message = "Pincode cannot be null")
    @Pattern(regexp = "^[0-9]{6}$", message = "Pincode should be exactly 6 digits")
    private String pincode;

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
    
    

}
