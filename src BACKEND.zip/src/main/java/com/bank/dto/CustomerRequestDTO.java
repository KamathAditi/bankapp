package com.bank.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
public class CustomerRequestDTO {

    @NotBlank(message = "Name is required")
    @Size(max = 25, message = "Name cannot exceed 25 characters")
    private String fullName;

    @NotBlank(message = "Contact number is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone number is invalid (+91)")
    private String contactNumber;

    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be in the past")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOfBirth;

    @Valid
    @NotNull
    private LoginRequestDTO login;

    @Valid
    @NotNull(message = "Address list is required")
    @Size(min = 1, message = "At least one address is required")
    private List<AddressRequestDTO> addresses;

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public LoginRequestDTO getLogin() {
		return login;
	}

	public void setLogin(LoginRequestDTO login) {
		this.login = login;
	}

	public List<AddressRequestDTO> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<AddressRequestDTO> addresses) {
		this.addresses = addresses;
	}
    
    


}
