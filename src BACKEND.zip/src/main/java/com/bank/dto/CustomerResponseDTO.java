package com.bank.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CustomerResponseDTO {

    private String customerId;
    private String fullName;
    private String contactNumber;
    private String dateOfBirth;
    private String email;
    private List<AddressResponseDTO> addresses;
    private List<AccountResponseDTO> accounts;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<AddressResponseDTO> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<AddressResponseDTO> addresses) {
		this.addresses = addresses;
	}
	public List<AccountResponseDTO> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<AccountResponseDTO> accounts) {
		this.accounts = accounts;
	}
    
    
}
