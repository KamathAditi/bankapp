package com.bank.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountRequestDTO {

    @NotNull(message = "Customer Id is required")
    private Long customerId;

    @NotNull(message = "Account Type is required")
    @Pattern(regexp = "^(SAVINGS|CURRENT|FIXED_DEPOSIT)$",
            message = "Account type must either be SAVINGS, CURRENT or FIXED_DEPOSIT")
    private String accountType;

    @NotNull(message = "Initial balance is required")
    @Min(value=100, message = "Initial balance must be greater than or equal to 100")
    private Double balance;

    private Long accountNumber;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
    
    
}
