package com.bank.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountStatementDto {
    String daily;
    String weekly;
    String monthly;
    String income;
    String expense;
    String totalCashFlow;
	public String getDaily() {
		return daily;
	}
	public void setDaily(String daily) {
		this.daily = daily;
	}
	public String getWeekly() {
		return weekly;
	}
	public void setWeekly(String weekly) {
		this.weekly = weekly;
	}
	public String getMonthly() {
		return monthly;
	}
	public void setMonthly(String monthly) {
		this.monthly = monthly;
	}
	public String getIncome() {
		return income;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public String getExpense() {
		return expense;
	}
	public void setExpense(String expense) {
		this.expense = expense;
	}
	public String getTotalCashFlow() {
		return totalCashFlow;
	}
	public void setTotalCashFlow(String totalCashFlow) {
		this.totalCashFlow = totalCashFlow;
	}

    
}
