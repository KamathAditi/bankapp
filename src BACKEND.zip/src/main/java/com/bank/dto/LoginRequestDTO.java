package com.bank.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequestDTO {

    @NotNull(message = "Email is required")
    @Email(message = "Email should valid")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 8, max = 20, message = "Password must be between 8 and 20 characters long.")
//    @Pattern.List({
//            @Pattern(regexp = ".*[a-z].*", message = "Password must contain at least one lowercase letter."),
//            @Pattern(regexp = ".*[A-Z].*", message = "Password must contain at least one uppercase letter."),
//            @Pattern(regexp = ".*\\d.*", message = "Password must contain at least one digit."),
//            @Pattern(regexp = ".*[!@#$%^&*(),.?\":{}|<>].*", message = "Password must contain at least one special character.")
//    })
    private String password;

    private String role;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
    
    

}
