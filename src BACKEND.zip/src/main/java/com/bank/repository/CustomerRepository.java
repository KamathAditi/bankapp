package com.bank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.entity.Customer;

import java.time.LocalDate;
import java.util.List;


public interface CustomerRepository extends JpaRepository<Customer, Long>{
    List<Customer> findByFullNameLike(String fullName);
    List<Customer> findByDateOfBirth(LocalDate dob);
    Customer findByAccounts_AccountNumber(Long accountsAccountNumber);
}
