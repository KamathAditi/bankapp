package com.bank.repository;

import com.bank.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    boolean existsByTransactionId(Long transactionId);

    @Query("SELECT t FROM Transaction t WHERE (t.senderAccountNumber = :accountNumber OR t.receiverAccountNumber = :accountNumber) ORDER BY t.timeStamp DESC ")
    List<Transaction> findAllByAccountNumber(@Param("accountNumber") Long accountNumber);

    @Query("SELECT t FROM Transaction t WHERE (t.senderAccountNumber = :accountNumber OR t.receiverAccountNumber = :accountNumber) AND t.timeStamp BETWEEN :startDate AND :endDate ORDER BY t.timeStamp DESC")
    List<Transaction> findAllByAccountAndTimestampBetween(
            @Param("accountNumber") Long accountNumber,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate);

    @Query("SELECT t FROM Transaction t WHERE t.senderAccountNumber IN :accountNumbers OR t.receiverAccountNumber IN :accountNumbers  ORDER BY t.timeStamp DESC")
    List<Transaction> findByAccountNumbers(@Param("accountNumbers") List<Long> accountNumbers);

}
