package com.bank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

import com.bank.entity.Login;

public interface LoginRepository extends JpaRepository<Login, Long> {
    Optional<Login> findByEmail(String Email);
    boolean existsByEmail(String Email);

}
