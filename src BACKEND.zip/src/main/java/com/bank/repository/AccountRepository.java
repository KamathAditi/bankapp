package com.bank.repository;

import com.bank.dto.AccountResponseDTO;
import com.bank.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.entity.Account;
import org.springframework.stereotype.Repository;

import java.util.List;


public interface AccountRepository extends JpaRepository<Account, Long>{

    boolean existsByAccountNumber(Long accountNumber);

    Account getAccountByAccountNumber(Long accountNumber);

    List<Account> findByCustomer_CustomerIdOrderByCreatedAt(Long customerCustomerId);

}
