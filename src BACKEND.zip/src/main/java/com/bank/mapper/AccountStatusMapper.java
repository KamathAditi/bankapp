package com.bank.mapper;

import com.bank.dto.AccountStatusResponse;
import com.bank.entity.Account;

public class AccountStatusMapper {
    public static AccountStatusResponse toResponse(Long accountNumber, String accountStatus) {
        AccountStatusResponse accountStatusResponse = new AccountStatusResponse();
        accountStatusResponse.setAccountNumber(accountNumber);
        accountStatusResponse.setStatus(accountStatus);
        return accountStatusResponse;
    }
}
