package com.bank.mapper;

import com.bank.dto.TransactionRequestDTO;
import com.bank.dto.TransactionResponseDTO;
import com.bank.entity.Transaction;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class TransactionMapper {

    public static TransactionResponseDTO transactionToDto(Transaction transaction) {

        TransactionResponseDTO transactionDTO = new TransactionResponseDTO();
        transactionDTO.setTransactionId(Long.toString(transaction.getTransactionId()));
        transactionDTO.setTransactionType(transaction.getTransactionType());
        transactionDTO.setTimeStamp(transaction.getTimeStamp().toString());
        transactionDTO.setAmount(Double.toString(transaction.getAmount()));
        transactionDTO.setStatus(transaction.getStatus());
        transactionDTO.setDescription(transaction.getDescription());
        transactionDTO.setSenderAccountNumber(Long.toString(transaction.getSenderAccountNumber()));
        if(transaction.getTransactionType().equals("TRANSFER")) {
            transactionDTO.setReceiverAccountNumber(Long.toString(transaction.getReceiverAccountNumber()));
        }

        return transactionDTO;

    }

    public static Transaction transactionToModel(TransactionRequestDTO transactionDTO) {
        Transaction transaction = new Transaction();
        transaction.setTransactionId(transactionDTO.getTransactionId());
        transaction.setTransactionType(transactionDTO.getTransactionType());
        transaction.setSenderAccountNumber(transactionDTO.getSenderAccountNumber());
        transaction.setDescription(transactionDTO.getDescription());
        transaction.setReceiverAccountNumber(transactionDTO.getReceiverAccountNumber());
        transaction.setAmount(transactionDTO.getAmount());
        transaction.setStatus(transactionDTO.getStatus());
        transaction.setAccount(transactionDTO.getAccount());

        return transaction;
    }

}
