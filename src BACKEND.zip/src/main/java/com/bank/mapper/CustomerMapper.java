package com.bank.mapper;

import com.bank.dto.*;
import com.bank.entity.Account;
import com.bank.entity.Address;
import com.bank.entity.Customer;
import com.bank.entity.Login;
import com.bank.exception.AddressNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CustomerMapper {

    public static CustomerResponseDTO customerToDTO(Customer customer) {
        CustomerResponseDTO customerDTO = new CustomerResponseDTO();
        customerDTO.setCustomerId(customer.getCustomerId().toString());
        customerDTO.setFullName(customer.getFullName());
        customerDTO.setContactNumber(customer.getContactNumber());
        customerDTO.setDateOfBirth(customer.getDateOfBirth().toString());

        LoginResponseDTO loginResponseDTO = loginToDTO(customer.getLogin());
        customerDTO.setEmail(loginResponseDTO.getEmail());

        List<AddressResponseDTO> addressDTOS = new ArrayList<>();
        if (customer.getAddresses() != null) {
            for (Address address : customer.getAddresses()) {
                addressDTOS.add(addressToDTO(address));
            }
        }
        else {
            throw new AddressNotFoundException("No address found");
        }
        customerDTO.setAddresses(addressDTOS);

        List<AccountResponseDTO> accountDTOS = new ArrayList<>();
        if (customer.getAccounts() != null){
            for (Account account : customer.getAccounts()) {
                accountDTOS.add(AccountMapper.accountToDTO(account));
            }
        }
        customerDTO.setAccounts(accountDTOS);

        return customerDTO;
    }

    public static LoginResponseDTO loginToDTO(Login login){
        LoginResponseDTO loginDTO = new LoginResponseDTO();
        loginDTO.setEmail(login.getEmail());
        return loginDTO;
    }

    public static AddressResponseDTO addressToDTO(Address address) {
        AddressResponseDTO addressDTO = new AddressResponseDTO();
        addressDTO.setAddressId(address.getId().toString());
        addressDTO.setDoorNumber(address.getDoorNumber());
        addressDTO.setCity(address.getCity());
        addressDTO.setState(address.getState());
        addressDTO.setStreetName(address.getStreetName());
        addressDTO.setPincode(address.getPincode().toString());
        return addressDTO;
    }

    public static Customer customerToModel(CustomerRequestDTO customerRequestDTO, String role) {
        Customer customer = new Customer();
        customer.setFullName(customerRequestDTO.getFullName());
        customer.setContactNumber(customerRequestDTO.getContactNumber());
        customer.setDateOfBirth(customerRequestDTO.getDateOfBirth());

        Login login;
        LoginRequestDTO loginRequestDTO = customerRequestDTO.getLogin();
        login = loginToModel(loginRequestDTO, customer, role);

        customer.setLogin(login);

        List<Address> addresses = new ArrayList<>();
        if (customerRequestDTO.getAddresses() != null) {
            for (AddressRequestDTO addressDTO : customerRequestDTO.getAddresses()) {
                addresses.add(addressToModel(addressDTO, customer));
            }
        }
        customer.setAddresses(addresses);
        return customer;
    }

    public static Login loginToModel(LoginRequestDTO loginRequestDTO, Customer customer, String role) {
        Login login = new Login();
        login.setEmail(loginRequestDTO.getEmail());
        login.setPassword(encryptPassword(loginRequestDTO.getPassword()));
        login.setRole(role);
        login.setCustomer(customer);
        return login;
    }

    public static Address addressToModel(AddressRequestDTO addressDTO, Customer customer) {
        Address address = new Address();
        address.setDoorNumber(addressDTO.getDoorNumber());
        address.setCity(addressDTO.getCity());
        address.setState(addressDTO.getState());
        address.setStreetName(addressDTO.getStreetName());
        address.setPincode(Integer.parseInt(addressDTO.getPincode()));
        address.setCustomer(customer);
        return address;
    }


    private static String encryptPassword(String password) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.encode(password);
    }
}
