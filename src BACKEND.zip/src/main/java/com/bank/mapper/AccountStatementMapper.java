package com.bank.mapper;

import com.bank.dto.AccountStatementDto;

import java.math.BigDecimal;

public class AccountStatementMapper {

    public static AccountStatementDto toDto(BigDecimal daily, BigDecimal weekly, BigDecimal monthly,
                                            BigDecimal income, BigDecimal expense, BigDecimal totalCashFlow) {
        AccountStatementDto dto = new AccountStatementDto();
        dto.setDaily(daily.toPlainString());
        dto.setWeekly(weekly.toPlainString());
        dto.setMonthly(monthly.toPlainString());
        dto.setIncome(income.toPlainString());
        dto.setExpense(expense.toPlainString());
        dto.setTotalCashFlow(totalCashFlow.toPlainString());
        return dto;
    }
}