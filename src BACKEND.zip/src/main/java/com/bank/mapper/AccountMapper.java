package com.bank.mapper;

import com.bank.dto.AccountRequestDTO;
import com.bank.dto.AccountResponseDTO;
import com.bank.entity.Account;
import com.bank.entity.Customer;


public class AccountMapper {


    public static AccountResponseDTO accountToDTO(Account account) {
        AccountResponseDTO accountResponseDTO = new AccountResponseDTO();
        accountResponseDTO.setAccountNumber(Long.toString(account.getAccountNumber()));
        accountResponseDTO.setAccountType(account.getAccountType());
        accountResponseDTO.setBalance(Double.toString(account.getBalance()));
        accountResponseDTO.setFrozen(Boolean.toString(account.getFrozen()));
        accountResponseDTO.setCreatedAt(account.getCreatedAt().toString());
//        List<TransactionResponseDTO> transactions = new ArrayList<>();
//        if (account.getTransactions() != null) {
//            for (Transaction transaction : account.getTransactions()) {
//                transactions.add(TransactionMapper.transactionToDto(transaction));
//            }
//        }
//        accountResponseDTO.setTransactions(transactions);
        return accountResponseDTO;
    }

    public static Account accountToModel(AccountRequestDTO accountRequestDTO, Customer customer) {
        Account account = new Account();
        account.setAccountNumber(accountRequestDTO.getAccountNumber());
        account.setAccountType(accountRequestDTO.getAccountType());
        account.setBalance(accountRequestDTO.getBalance());
        account.setFrozen(false);
        account.setCustomer(customer);
        return account;
    }


//

}
