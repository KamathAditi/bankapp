package com.bank.security;

import com.bank.dto.LoginRequestDTO;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;


@Service
public class JwtService {

    @Value("${jwt.secret}")
    private String secretKey;

    @Value("${jwt.expiration}")
    private Long expiration;

    @Value("${jwt.refreshExpiration}")
    private long refreshExpiration;


    public String generateToken(LoginRequestDTO login) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("role","ROLE_" + login.getRole());
        return Jwts
                .builder()
                .claims()
                .add(claims)
                .subject(login.getEmail())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + expiration))
                .and()
                .signWith(generateKey())
                .compact();

    }

//    public String getEmailfromToken(String token) {
//        return Jwts.parser().setSigningKey(secretKey).parseClaimsJwts(token).getBody().getSubject();
//    }

    public String generateRefreshToken(LoginRequestDTO login) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("role","ROLE_" + login.getRole());
        return Jwts
                .builder()
                .claims()
                .add(claims)
                .subject(login.getEmail())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + refreshExpiration))
                .and()
                .signWith(generateKey())
                .compact();

    }


    public SecretKey generateKey() {
        byte[] decoded = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(decoded);
    }

    public String extractEmail(String jwtToken) {
        return extractClaims(jwtToken, Claims::getSubject);
    }

    public String extractRole(String jwtToken) {
        return extractClaims(jwtToken, claims -> claims.get("role", String.class));
    }

    private <T> T extractClaims(String jwtToken, Function<Claims, T> claimResolver) {
        Claims claims = extractClaims(jwtToken);
        return claimResolver.apply(claims);
    }

    private Claims extractClaims(String jwtToken) {

        if (jwtToken == null || jwtToken.split("\\.").length != 3) {
            throw new IllegalArgumentException("Invalid JWT token format.");
        }

        return Jwts.parser()
             .setSigningKey(generateKey())
            .build()
            .parseClaimsJws(jwtToken)
            .getBody();
    }


    public boolean isTokenValid(String jwtToken, UserDetails userDetails) {
        final String email = extractEmail(jwtToken);
        final String role = extractRole(jwtToken);
        return (email.equals(userDetails.getUsername()) && !isTokenExpired(jwtToken) && role.equals(userDetails.getAuthorities().iterator().next().getAuthority()));
    }

    private boolean isTokenExpired(String jwtToken) {
        return extractExpiration(jwtToken).before(new Date());
    }

    private Date extractExpiration(String jwtToken) {
        return extractClaims(jwtToken, Claims::getExpiration);
    }



}
