import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { authGuard } from './guard/auth.guard';
import { UserDashboardComponent } from './dashboard/user-dashboard/user-dashboard.component';
import { AddAccountComponent } from './components/add-account/add-account.component';
import { UserLayoutComponent } from './components/user-layout/user-layout.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { AdminComponent } from './components/admin/admin.component';
import { AccountComponent } from './components/admin/accounts/account/account.component';
import { AccountActionComponent } from './components/admin/accounts/accountaction/accountaction.component';
import { AccountBalanceComponent } from './components/admin/accounts/accountbalance/accountbalance.component';
import { AccountCreateComponent } from './components/admin/accounts/accountcreate/accountcreate.component';
import { AccountDetailComponent } from './components/admin/accounts/accountdetail/accountdetail.component';
import { AccountExistenceComponent } from './components/admin/accounts/accountexistence/accountexistence.component';
import { AccountListComponent } from './components/admin/accounts/accountlist/accountlist.component';
import { AddAdminComponent } from './components/admin/customer/addadmin/addadmin.component';
import { CustomerComponent } from './components/admin/customer/customer.component';
import { CustomerListComponent } from './components/admin/customer/customerlist/customerlist.component';
import { GetCustomerComponent } from './components/admin/customer/getcustomer/getcustomer.component';
import { DepositComponent } from './components/admin/transaction/deposit/deposit.component';
import { TransactionComponent } from './components/admin/transaction/transaction.component';
import { TransactionsComponent } from './components/admin/transaction/transactions/transactions.component';
import { TransactionsDateRangeComponent } from './components/admin/transaction/transactionsdaterange/transactionsdaterange.component';
import { WithdrawComponent } from './components/admin/transaction/withdraw/withdraw.component';
import { TransferComponent } from './components/transfer/transfer.component';
import { Transfer } from './components/admin/transaction/transfer/transfer.component';
import { DashboardComponent } from './components/admin/dashboard/dashboard.component';

export const routes: Routes =
  [
    {
      path: '',
      redirectTo: 'login',
      pathMatch: 'full'
    },
    {
      path: 'login',
      component: LoginComponent
    },
    {
      path: 'register',
      component: RegisterComponent
    },
    {
      path: 'dashboard',
      canActivate: [authGuard],
      component: UserLayoutComponent,
      children: [
        {
          path: '',
          canActivate: [authGuard],
          component: UserDashboardComponent
        },
        {
          path: 'add-account',
          canActivate: [authGuard],
          component: AddAccountComponent
        },
        // need to change this to adhere for accound card
        {
          path: 'account',
          canActivate: [authGuard],
          component: AccountDetailsComponent
        },
        {
          path: 'profile',
          canActivate: [authGuard],
          component: UserProfileComponent,
        },
      ]
    },
    {
      path: 'admin',
      canActivate: [authGuard],
      component: AdminComponent,
      children: [

        { path: 'accounts', component: AccountComponent, canActivate: [authGuard], data: { role: 'ADMIN' } },
        { path: 'accounts/create', component: AccountCreateComponent, canActivate: [authGuard] },
        { path: 'accountbalance', component: AccountBalanceComponent, canActivate: [authGuard] },
        { path: 'accountlist', component: AccountListComponent, canActivate: [authGuard] },
        { path: 'accountcreate', component: AccountCreateComponent, canActivate: [authGuard] },
        { path: 'accountdetails', component: AccountDetailComponent, canActivate: [authGuard] },
        { path: 'accountexistence', component: AccountExistenceComponent, canActivate: [authGuard] },
        { path: 'accountaction', component: AccountActionComponent, canActivate: [authGuard] },
        { path: 'account', component: AccountComponent, canActivate: [authGuard] },
        { path: 'transaction', component: TransactionComponent, canActivate: [authGuard] },
        { path: 'deposit', component: DepositComponent, canActivate: [authGuard] },
        { path: 'withdraw', component: WithdrawComponent, canActivate: [authGuard] },
        { path: 'transfer', component: Transfer, canActivate: [authGuard] },
        { path: 'transactions', component: TransactionsComponent, canActivate: [authGuard] },
        { path: 'transactionsdaterange', component: TransactionsDateRangeComponent, canActivate: [authGuard] },
        { path: 'customer', component: CustomerComponent, canActivate: [authGuard] },
        { path: 'addadmin', component: AddAdminComponent, canActivate: [authGuard] },
        { path: 'customerlist', component: CustomerListComponent, canActivate: [authGuard] },
        { path: 'getcustomer', component: GetCustomerComponent, canActivate: [authGuard] },
        { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },

      ]
    },



  ];
