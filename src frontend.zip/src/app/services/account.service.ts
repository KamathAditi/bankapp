import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Account } from '../model/account/account';
import { AccountRequest } from '../model/account/account-request';
import { Statement } from '../model/statement/statement';
import { Accountrequestdto } from '../model/admin/models/accountrequestdto';
import { Accountresponsedto } from '../model/admin/models/accountresponsedto';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  

  private readonly API_URL = 'http://localhost:9000/accounts';

  constructor(private http: HttpClient) { }

  getAccountsByCustomerId(customerId: number): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.API_URL}/getAccountByCustomerId/${customerId}`);
  }
  
  getAccountDetails(accountNumber: string): Observable<Account> {
    return this.http.get<Account>(`${this.API_URL}/${accountNumber}`);
  }

  addAccount(newAccount: AccountRequest): Observable<Account> {
    return this.http.post<Account>(this.API_URL, newAccount);
  }

  deleteAccount(accountNumber: string): Observable<any> {
    return this.http.delete(`${this.API_URL}/${accountNumber}`);
  }

  getStatement(customerId: number): Observable<Statement> {
    return this.http.get<Statement>(`${this.API_URL}/statement/${customerId}`);
  }

   getBalance(accountNumber: string): Observable<number> {
    return this.http.get<number>(`${this.API_URL}/${accountNumber}/balance`);
  }

   existsAccount(accountNumber: string): Observable<boolean> {
    return this.http.get<boolean>(`${this.API_URL}/exists/${accountNumber}`);
  }

  freezeAccount(accountNumber: string): Observable<string> {
    return this.http.post<string>(`${this.API_URL}/${accountNumber}/freeze`, {});
  }
  unfreezeAccount(accountNumber: string): Observable<string> {
    return this.http.post<string>(`${this.API_URL}/${accountNumber}/unfreeze`, {});
  }
   getAccountHolder(accountNumber: string): Observable<any> {
    return this.http.get<any>(`${this.API_URL}/${accountNumber}/holder`);
  }

  createAccount(accountRequestDTO: Accountrequestdto): Observable<Accountresponsedto> {
    return this.http.post<Accountresponsedto>(`${this.API_URL}`, accountRequestDTO);
  }

  getAccountsByAccountNumber(accountNumber: string): Observable<Accountresponsedto> {
    return this.http.get<Accountresponsedto>(`${this.API_URL}/${accountNumber}`);
  }

  // Deposit money into an account
  deposit(accountNumber: string, amount: number): Observable<any> {
    return this.http.post<any>(`${this.API_URL}/${accountNumber}/deposit/${amount}`, {});
  }

  // Withdraw money from an account
  withdraw(accountNumber: string, amount: number): Observable<any> {
    return this.http.post<any>(`${this.API_URL}/${accountNumber}/withdraw/${amount}`, {});
  }

  // Transfer money from one account to another
  transfer(senderAccountNumber: string, receiverAccountNumber: string, amount: number): Observable<any> {
    return this.http.post<any>(`${this.API_URL}/${senderAccountNumber}/transfer/${receiverAccountNumber}/${amount}`, {});
  }
  getAllAccounts(): Observable<Accountresponsedto[]> {
    return this.http.get<Accountresponsedto[]>(`${this.API_URL}`);
  }

  getAccountsByAccountNumbers(accountNumber: string): Observable<Accountresponsedto> {
    return this.http.get<Accountresponsedto>(`${this.API_URL}/${accountNumber}`);
  }
  getAccountsByCustomerIds(customerId: number): Observable<Accountresponsedto[]> {
    return this.http.get<Accountresponsedto[]>(`${this.API_URL}/getAccountByCustomerId/${customerId}`);
  }
}
