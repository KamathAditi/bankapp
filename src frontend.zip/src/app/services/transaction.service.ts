import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Transaction } from '../model/transaction/transaction';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  private readonly API_URL = 'http://localhost:9000/accounts';


  constructor(private http: HttpClient) { }

  deposit(accountNumber: string, amount: number): Observable<Transaction> {
    return this.http.post<Transaction>(`${this.API_URL}/${accountNumber}/deposit/${amount}`, {});
  }

  withdraw(accountNumber: string, amount: number): Observable<Transaction> {
    return this.http.post<Transaction>(`${this.API_URL}/${accountNumber}/withdraw/${amount}`, {});
  }

  transfer(senderAccountNumber: string, receiverAccountNumber: string, amount: number): Observable<Transaction> {
    return this.http.post<Transaction>(`${this.API_URL}/${senderAccountNumber}/transfer/${receiverAccountNumber}/${amount}`, {});
  }

  getTransactions(accountNumber: string): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.API_URL}/${accountNumber}/transactions`);
  }

  getTransactionsBetweenDates(accountNumber: string, startDate: string, endDate: string): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.API_URL}/${accountNumber}/transactions/${startDate}/${endDate}`);
  }

  transferAmount(senderAccountNumber: string, receiverAccountNumber: string, amount: number): Observable<string> {
    return this.http.post<string>(
      `${this.API_URL}/${senderAccountNumber}/transfer/${receiverAccountNumber}/${amount}`,
      null,
      { responseType: 'text' as 'json' }  // Expecting plain text response
    );
  }
}
