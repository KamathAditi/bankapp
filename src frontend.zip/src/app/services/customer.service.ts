import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { Observable } from 'rxjs';
import { CustomerResponseDto } from '../model/Customer/customer-response-dto';
import { AddressDto } from '../model/address/address-dto';
import { CustomerRequestDto } from '../model/Customer/customer-request-dto';
import { CustomerRequestDTO } from '../model/admin/models/customerrequestdto';
import { CustomerResponseDTO } from '../model/admin/models/customerresponsedto';
import { AddressRequestDto } from '../model/address/address-request-dto';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private readonly API_URL = 'http://localhost:9000/customer';
  
  constructor(private http: HttpClient, private authService: AuthService) { }

  getCustomerDetails(): Observable<CustomerResponseDto> {
    return this.http.get<any>(`${this.API_URL}/me`);
  }

  
  // Get all customers
   getAllCustomers(): Observable<CustomerResponseDto[]> {
    return this.http.get<CustomerResponseDto[]>(`${this.API_URL}`);
  }

  // Get a customer by ID
  getCustomerById(customerId: number): Observable<CustomerResponseDto> {
    return this.http.get<CustomerResponseDto>(`${this.API_URL}/${customerId}`);
  }
  
  // Get customer by name
  getCustomerByName(name: string): Observable<CustomerResponseDto[]> {
    return this.http.get<CustomerResponseDto[]>(`${this.API_URL}/findbyname/${name}`);
  }

  // Get customer by Date of Birth (DOB)
  getCustomerByDob(dob: string): Observable<CustomerResponseDto[]> {
    return this.http.get<CustomerResponseDto[]>(`${this.API_URL}/findbydob/${dob}`);
  }

  // Get customer by email
  getCustomerByEmail(email: string): Observable<CustomerResponseDto[]> {
    return this.http.get<CustomerResponseDto[]>(`${this.API_URL}/findbyemail/${email}`);
  }

  // Add a new admin
  addAdmin(customer: CustomerRequestDto): Observable<CustomerResponseDto> {
    return this.http.post<CustomerResponseDto>(`${this.API_URL}/addadmin`, customer);
  }

  // Full update of customer (PUT - replace the entire resource)
  updateCustomer(customerId: number, customer: CustomerResponseDto): Observable<CustomerResponseDto> {
    return this.http.put<CustomerResponseDto>(`${this.API_URL}/${customerId}`, customer);
  }

  // Partial update of customer name (PATCH - update only the name)
  updateCustomerName(customerId: number, name: string): Observable<CustomerResponseDto> {
    return this.http.patch<CustomerResponseDto>(`${this.API_URL}/${customerId}/name`, { fullName: name });
  }

  // Partial update of customer DOB (PATCH - update only the DOB)
  updateCustomerDob(customerId: number, dob: string): Observable<CustomerResponseDto> {
    return this.http.patch<CustomerResponseDto>(`${this.API_URL}/${customerId}/dob`, { dateOfBirth: dob });
  }

  // Partial update of customer address (PATCH - update only the address)
  updateCustomerAddress(customerId: number, addressId: string, address: AddressRequestDto): Observable<CustomerResponseDto> {
    return this.http.patch<CustomerResponseDto>(`${this.API_URL}/${customerId}/${addressId}`,  address );
  }

  // Delete a customer by ID
  deleteCustomer(customerId: number): Observable<void> {
    return this.http.delete<void>(`${this.API_URL}/${customerId}`);
  }

  addAdmins(customer: CustomerRequestDTO): Observable<CustomerResponseDTO> {
    return this.http.post<CustomerResponseDTO>(`${this.API_URL}/addadmin`, customer);
  }
  updateCustomerAddresss(customerId: number,  newAddress: any): Observable<CustomerResponseDTO> {    
    const url = `${this.API_URL}/${customerId}/{addressId}`;
    return this.http.patch<CustomerResponseDTO>(url, newAddress);
  }

  getCustomerByIds(id: number): Observable<CustomerResponseDTO> {
    return this.http.get<CustomerResponseDTO>(`${this.API_URL}/${id}`);
  }

  getCustomerByNames(name: string): Observable<CustomerResponseDTO[]> {
    return this.http.get<CustomerResponseDTO[]>(`${this.API_URL}/findbyname/${name}`);
  }

  // Fetch customer by date of birth
  getCustomerByDobs(dob: string): Observable<CustomerResponseDTO[]> {
    return this.http.get<CustomerResponseDTO[]>(`${this.API_URL}/findbydob/${dob}`);
  }
  getCustomerByEmails(email: string): Observable<CustomerResponseDTO> {
    return this.http.get<CustomerResponseDTO>(`${this.API_URL}/findbyemail/${email}`);
  }
}
