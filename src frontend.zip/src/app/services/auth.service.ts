import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginRequestDto } from '../model/login/login-request-dto';
import { CustomerRequestDto } from '../model/Customer/customer-request-dto';
import { isPlatformBrowser } from '@angular/common';
import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly API_URL = 'http://localhost:9000/auth';

  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) private platformId: Object
  ) { }

  login(loginData: LoginRequestDto): Observable<any> {
    return this.http.post(`${this.API_URL}/login`, loginData);
  }

  register(customerData: CustomerRequestDto): Observable<any> {
    return this.http.post(`${this.API_URL}/register`, customerData);
  }

  saveToken(token: string): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('token', token);
    }
  }

  getToken(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('token');
    }
    return null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  removeToken(): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('token');
    }
  }

  logout(): void {
    if (this.isLoggedIn()) {
      this.removeToken();
    }
  }

  getRole(): string | null {
    const token = this.getToken();  // Calling the method to get the token
    if (token) {
      try {
        const decodedToken: any = jwtDecode(token);
        const role = decodedToken.role ? decodedToken.role.replace('ROLE_', '') : null;
        return role;
      } catch (error) {
        console.error('Error decoding token', error);
        return null;
      }
    }
    return null;  // Return null if no token is found
  }
}
