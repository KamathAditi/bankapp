import { Component, Input } from '@angular/core';
import { TransactionService } from '../../services/transaction.service';
import { Transaction } from '../../model/transaction/transaction';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {  Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-account-transactions',
  imports: [CommonModule, FormsModule],
  templateUrl: './account-transactions.component.html',
  styleUrl: './account-transactions.component.css'
})
export class AccountTransactionsComponent {

  @Input() accountNumber: string | null = null;
  @Input() createdAt: string | null = null;
  transactions: Transaction[] = [];
  paginatedTransactions: Transaction[] = [];
  pageSize: number = 5;
  currentPage: number = 0;
  totalPages: number = 0;

  startDate: string | null = null;
  endDate: string | null = null;

  minStartDate: string | null = null;
  maxStartDate: string | null = null;
  maxEndDate: string | null = null;
  minEndDate: string | null = null;
  noTransactionsFound: boolean = false;
  loading: boolean = true;

  dateButton: boolean = true;
  showFilters: boolean = false;

  errorMessage: string = '';

  constructor(private transactionService: TransactionService, private router: Router) { }

  ngOnInit(): void {
    const today = new Date();
    this.minStartDate = this.createdAt;
    this.maxStartDate = today.toISOString().split('T')[0];
    this.maxEndDate = today.toISOString().split('T')[0];
    this.listTransactions();
  }

 

  listTransactions() {
    if (this.accountNumber) {
      this.loading = true;

      if (this.startDate && this.endDate) {
        // Fetch transactions between the provided dates
        this.transactionService.getTransactionsBetweenDates(this.accountNumber, this.startDate, this.endDate).subscribe({
          next: (data: Transaction[]) => {
            this.noTransactionsFound = false;
            this.errorMessage = '';
            this.transactions = data;  // Store the fetched transactions
            this.totalPages = Math.ceil(this.transactions.length / this.pageSize);  // Update the total pages
            this.updatePaginatedTransactions();  // Apply pagination
            this.loading = false;
          },
          error: (error) => {
            if (error.status === 400) {
              console.error('No transactions found for the selected dates', error);
              this.transactions = [];
              this.noTransactionsFound = true;
              this.totalPages = 0;
              this.loading = false;
            }
            this.loading = false;
          }
        });
      } else {
        this.transactionService.getTransactions(this.accountNumber!).subscribe({
          next: (data: Transaction[]) => {
            this.noTransactionsFound = false;
            this.errorMessage = '';
            this.transactions = data;  // Store the fetched transactions
            this.totalPages = Math.ceil(this.transactions.length / this.pageSize);  // Update the total pages
            this.updatePaginatedTransactions();  // Apply pagination
            this.loading = false;
          },
          error: (error) => {
            this.noTransactionsFound = true;
            this.loading = false;
          }
        });
      }
    } else {
      console.error('Account number is missing');
      this.loading = false;
    }
  }

  updatePaginatedTransactions() {
    this.paginatedTransactions = this.transactions.slice(
      this.currentPage * this.pageSize,
      (this.currentPage + 1) * this.pageSize
    );
  }

  previousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.updatePaginatedTransactions();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.updatePaginatedTransactions();
    }
  }

  // Apply the date filter when clicking the Apply Filter button
  applyDateFilter() {
    if (this.startDate && this.endDate) {
      this.dateButton = false;
      this.listTransactions();
      this.showFilters = false; // Hide filters after applying
    }
  }

  resetDateFilter() {
    this.startDate = null;
    this.endDate = null;
    this.dateButton = true;
    this.minEndDate = null;
    this.listTransactions();
    this.showFilters = false; // Hide filters after resetting
  }

  setStartDate() {
    this.minEndDate = this.startDate;
  }

  toggleFilters() {
    this.showFilters = !this.showFilters;
  }

  // Helper method to get transaction description
  getTransactionTypeLabel(type: string): string {
    switch (type) {
      case 'DEPOSIT': return 'Deposit';
      case 'WITHDRAW': return 'Withdraw';
      case 'TRANSFER': return 'Transfer';
      default: return type;
    }
  }

}
