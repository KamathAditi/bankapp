import { Component } from '@angular/core';
import { AccountService } from '../../services/account.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Account } from '../../model/account/account';
import { CustomerService } from '../../services/customer.service';
import { CustomerResponseDto } from '../../model/Customer/customer-response-dto';
import { finalize, timer } from 'rxjs';
import { Router } from '@angular/router';

export type TransactionType = 'deposit' | 'withdraw' | 'transfer';


@Component({
  selector: 'app-transfer',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './transfer.component.html',
  styleUrl: './transfer.component.css'
})
export class TransferComponent {
 transferForm: FormGroup;
  isLoading = false;
  accounts: Account[] = [];
  errorMessage: string | null = null;
  successMessage: string | null = null;
  selectedType: TransactionType = 'deposit';
  customerData: CustomerResponseDto | null = null;
  customerId: number | null = null;
  selectedAccount: Account | null = null;

  transactionTypes: TransactionType[] = ['deposit', 'withdraw', 'transfer'];

  constructor(
    private fb: FormBuilder,
    private accountService: AccountService,
    private customerService: CustomerService,
    private router: Router
  ) {
    this.transferForm = this.fb.group({
      fromAccount: ['', Validators.required],
      toAccount: [''],
      amount: ['', [Validators.required, Validators.min(0.01)]]
    });

    // Subscribe to account selection changes
    this.transferForm.get('fromAccount')?.valueChanges.subscribe(accountNumber => {
      this.selectedAccount = this.accounts.find(acc => acc.accountNumber === accountNumber) || null;
    });
  }

  ngOnInit(): void {
    this.loadCustomerData();
  }

  private loadCustomerData(): void {
    this.isLoading = true;
    this.customerService.getCustomerDetails()
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (data) => {
          this.customerData = data;
          this.customerId = data.customerId;
          if (this.customerId) {
            this.loadAccounts(this.customerId);
          }
        },
        error: (error) => {
          console.error('Error loading customer data:', error);
          this.errorMessage = 'Failed to load customer data. Please try again.';
        }
      });
  }

  private loadAccounts(customerId: number): void {
    this.isLoading = true;
    this.accountService.getAccountsByCustomerId(customerId)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (accounts) => {
          this.accounts = accounts;
          if (accounts.length === 0) {
            this.errorMessage = 'No accounts found. Please create an account first.';
          }
        },
        error: (error) => {
          console.error('Error loading accounts:', error);
          this.errorMessage = 'Failed to load accounts. Please try again.';
        }
      });
  }

  onTypeChange(type: TransactionType): void {
    this.selectedType = type;
    this.transferForm.reset();
    this.errorMessage = null;
    this.successMessage = null;

    // Update form validation based on transaction type
    const toAccountControl = this.transferForm.get('toAccount');
    if (type === 'transfer') {
      toAccountControl?.setValidators([
        Validators.required,
        (control) => {
          const fromAccount = this.transferForm.get('fromAccount')?.value;
          return fromAccount === control.value ? { sameAccount: true } : null;
        }
      ]);
    } else {
      toAccountControl?.clearValidators();
    }
    toAccountControl?.updateValueAndValidity();
  }

  onSubmit(): void {
    if (this.transferForm.valid) {
      this.isLoading = true;
      this.errorMessage = null;
      this.successMessage = null;

      const { fromAccount, toAccount, amount } = this.transferForm.value;
      const amountValue = parseFloat(amount);

      // Validate sufficient balance for withdrawal/transfer
      if (this.selectedAccount && (this.selectedType === 'withdraw' || this.selectedType === 'transfer')) {
        if (this.selectedAccount.balance < amountValue) {
          this.errorMessage = 'Insufficient funds for this transaction.';
          this.isLoading = false;
          return;
        }
      }

      switch (this.selectedType) {
        case 'deposit':
          this.accountService.deposit(fromAccount, amountValue)
            .pipe(finalize(() => this.isLoading = false))
            .subscribe({
              next: () => this.handleSuccess('Deposit', this.customerId as number),
              error: (error) => this.handleError(error)
            });
          break;

        case 'withdraw':
          this.accountService.withdraw(fromAccount, amountValue)
            .pipe(finalize(() => this.isLoading = false))
            .subscribe({
              next: () => this.handleSuccess('Withdrawal', this.customerId as number),
              error: (error) => this.handleError(error)
            });
          break;

        case 'transfer':
          this.accountService.transfer(fromAccount, toAccount, amountValue)
            .pipe(finalize(() => this.isLoading = false))
            .subscribe({
              next: () => this.handleSuccess('Transfer', this.customerId as number),
              error: (error) => this.handleError(error)
            });
          break;
      }
    } else {
      this.markFormGroupTouched(this.transferForm);
    }
  }

  private handleSuccess(operation: string, customerId: number): void {
    this.successMessage = `${operation} completed successfully`;
    this.transferForm.reset();
    
    // Add a short delay to show the success message
    timer(1000).subscribe(() => {
      // Navigate to dashboard with skipLocationChange to avoid changing browser history
      this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        // Then navigate to dashboard which forces a full component reload
        this.router.navigate(['/dashboard']);
      });
    });
  }

  private handleError(error: any): void {
    console.error('Transaction failed:', error);
    this.errorMessage = error.error.error || 'Transaction failed. Please try again.';
    this.isLoading = false;
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  formatCurrency(value: number | null | undefined): string {
    // Handle null, undefined, or NaN
    if (value === null || value === undefined || isNaN(value)) {
      return '0.00 $';
    }

    // Convert to number and ensure it's a valid number
    const num = Number(value);
    if (isNaN(num)) {
      return '0.00 $';
    }

    // Format with 2 decimal places
    const formattedValue = num.toFixed(2);

    // Split into whole and decimal parts
    const [whole, decimal] = formattedValue.split('.');

    // Add thousands separators to whole number part
    const formattedWhole = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    // Return formatted string with space before currency symbol
    return `${formattedWhole}.${decimal} $`;
  }

  getTypeIcon(type: TransactionType): string {
    switch (type) {
      case 'deposit':
        return 'M14.707 12.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l2.293-2.293a1 1 0 011.414 0z';
      case 'withdraw':
        return 'M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z';
      case 'transfer':
        return 'M8 5a1 1 0 100 2h5.586l-1.293 1.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L13.586 5H8zM12 15a1 1 0 100-2H6.414l1.293-1.293a1 1 0 10-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L6.414 15H12z';
    }
  }

  getTypeColor(type: TransactionType): string {
    switch (type) {
      case 'deposit':
        return 'blue';
      case 'withdraw':
        return 'orange';
      case 'transfer':
        return 'green';
    }
  }

  getAccountBalance(accountNumber: string): number {
    const account = this.accounts.find(acc => acc.accountNumber === accountNumber);
    return account?.balance || 0;
  }

  clearMessages(): void {
    this.errorMessage = null;
    this.successMessage = null;
  }
}
