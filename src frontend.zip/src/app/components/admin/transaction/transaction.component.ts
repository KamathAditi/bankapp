// import { Component } from '@angular/core';
// import { TransactionService } from '../services/transaction.service';
// import { FormsModule } from '@angular/forms';

// @Component({
//   selector: 'app-transaction',
//   standalone: true,
//   imports:[FormsModule],
//   templateUrl: './transaction.component.html',
//   styleUrls: ['./transaction.component.css']
// })
// export class TransactionComponent {

//   accountNumber: number = 0;
//   amount: number = 0;
//   receiverAccountNumber: number = 0;
//   transactionHistory: any[] = [];

//   constructor(private transactionService: TransactionService) { }

//   deposit(): void {
//     this.transactionService.deposit(this.accountNumber, this.amount).subscribe({
//       next: (data) => {
//         console.log('Deposit Successful:', data);
//       },
//       error: (error) => {
//         console.error('Error depositing money:', error);
//       }
//     });
//   }
//   withdraw(): void {
//     this.transactionService.deposit(this.accountNumber, this.amount).subscribe({
//       next: (data) => {
//         console.log('Deposit Successful:', data);
//       },
//       error: (error) => {
//         console.error('Error depositing money:', error);
//       }
//     });
//   }
// }

import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent {

  constructor(private router: Router) {}

  
  navigateToTransactions() {
    this.router.navigate(['admin/transactions']);
  }

  navigateToTransactionsDateRange() {
    this.router.navigate(['admin/transactionsdaterange']);
  }
}
