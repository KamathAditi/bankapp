import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TransactionResponseDTO } from '../../../../model/admin/models/transactionresponsedto';
import { TransactionService } from '../../../../services/transaction.service';

@Component({
  selector: 'app-transactions-date-range',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './transactionsdaterange.component.html',
  styleUrls: ['./transactionsdaterange.component.css'],
})
export class TransactionsDateRangeComponent {
  accountNumber: string | undefined;
  startDate: string = '';
  endDate: string = '';
  transactions: any[] = [];
  successMessage = '';
  errorMessage = '';

  constructor(private transactionService: TransactionService) {}

  fetchTransactions(): void {
    if (!this.accountNumber || !this.startDate || !this.endDate) {
      this.errorMessage = 'Please enter all required fields.';
      this.successMessage = '';
      return;
    }

    this.transactionService.getTransactionsBetweenDates(this.accountNumber, this.startDate, this.endDate).subscribe({
      next: (data) => {
        this.transactions = data;
        this.successMessage = 'Transactions fetched successfully.';
        this.errorMessage = '';
      },
      error: (err) => {
        console.error(err);
        this.successMessage = '';
        if (err.status === 404) {
          this.errorMessage = 'No transactions found in the selected date range.';
        } else if (err.status === 400) {
          this.errorMessage = 'Invalid date range or input.';
        } else {
          this.errorMessage = 'Something went wrong.';
        }
      }
    });
  }
}
