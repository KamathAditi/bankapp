import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TransactionService } from '../../../../services/transaction.service';

@Component({
  selector: 'app-withdraw',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css'],
})
export class WithdrawComponent {
  accountNumber: string | undefined;
  amount: number | undefined;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private transactionService: TransactionService, private router: Router) {}

  withdrawFromAccount(): void {
    // Check if the account number and amount are valid
    if (!this.accountNumber || !this.amount || this.amount <= 0) {
      this.errorMessage = 'Enter correct account number and amount.';
      this.successMessage = '';
      return;
    }

    // Call the withdraw API through the service
    this.transactionService.withdraw(this.accountNumber, this.amount).subscribe({
      next: (res) => {
        // If withdraw is successful, show the success message
        this.successMessage = 'Withdrawal successful';
        this.errorMessage = '';
      },
      error: (error) => {
        // Show the error message based on the backend error status
        if (error.status === 400) {
          this.errorMessage = 'Invalid account number. Please enter a valid account number.';
        } else if (error.status === 403) {
          this.errorMessage = 'Deposit failed: Account is frozen.';
        } else if (error.status === 402) {
          this.errorMessage = `Withdrawal failed: Insufficient balance. Current balance: ${error.balance}`;
        } else {
          this.errorMessage = 'Withdrawal failed. Please try again.';
        }
        this.successMessage = '';
      }
    });
  }
}
