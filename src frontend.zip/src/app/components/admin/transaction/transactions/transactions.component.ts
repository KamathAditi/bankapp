import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TransactionService } from '../../../../services/transaction.service';

@Component({
  selector: 'app-transactions',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css'],
})
export class TransactionsComponent {
  accountNumber: string | undefined;
  transactions: any[] = [];
  successMessage = '';
  errorMessage = '';

  constructor(private transactionService: TransactionService) {}

  getTransactions(): void {
    if (!this.accountNumber) {
      this.errorMessage = 'Please enter a valid account number.';
      this.successMessage = '';
      return;
    }

    this.transactionService.getTransactions(this.accountNumber).subscribe({
      next: (data) => {

        this.transactions = data
        this.successMessage = 'Transactions loaded successfully.';
        this.errorMessage = '';
      },
      error: (error) => {
        console.error('Transaction fetch error:', error);
        this.transactions = [];
        this.successMessage = '';
        this.errorMessage = error.status === 404
          ? 'No transactions found for this account.'
          : 'Error loading transactions.';
      },
    });
  }
}
