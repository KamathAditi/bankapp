import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TransactionService } from '../../../../services/transaction.service';

@Component({
  selector: 'app-transfer',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css'],
})
export class Transfer {
  senderAccountNumber: string | undefined;
  receiverAccountNumber: string | undefined;
  amount: number | undefined;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private transactionService: TransactionService, private router: Router) {}

  // Transfer amount from sender to receiver
  transferAmount(): void {
    if (!this.senderAccountNumber || !this.receiverAccountNumber || !this.amount || this.amount <= 0) {
      this.errorMessage = 'Please enter valid account numbers and amount.';
      this.successMessage = '';
      return;
    }

    this.transactionService.transferAmount(this.senderAccountNumber, this.receiverAccountNumber, this.amount).subscribe({
      next: (res) => {
        // If transfer is successful, show success message
        this.successMessage = 'Transfer successful';
        this.errorMessage = '';
      },
      error: (error) => {
        // If there was an error, show error message
        console.error('Transfer error:', error);

        if (error.status === 404) {
          this.errorMessage = 'Account not found. Please enter valid account numbers.';
        } else if (error.status === 400) {
          this.errorMessage = 'Transfer failed. Insufficient balance or invalid input.';
        } else {
          this.errorMessage = 'Transfer failed. Please try again later.';
        }

        this.successMessage = '';
      }
    });
  }
}
