import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TransactionService } from '../../../../services/transaction.service';
import { DepositResponse } from '../../../../model/admin/models/depositresponse';
  // Import DepositResponse class

@Component({
  selector: 'app-deposit',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css'],
})
export class DepositComponent {
  accountNumber: string | undefined;
  amount: number | undefined;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private transactionService: TransactionService, private router: Router) {}

  depositToAccount(): void {
    // Check if the account number and amount are valid
    if (!this.accountNumber || !this.amount || this.amount <= 0) {
      this.errorMessage = 'Enter correct account number and amount.';
      this.successMessage = '';
      return;
    }

    // Call the deposit API through the service
    this.transactionService.deposit(this.accountNumber, this.amount).subscribe({
      
      next: (res: any) => {
        console.log('Backend response:', res); // Log the full response

        // Check backend response for specific status (account frozen case)
        if (res.status === 'Account frozen') {
          this.errorMessage = 'Deposit failed: Account is frozen.';
          this.successMessage = '';
        } else {
          // Other success or error responses can be handled normally
          this.successMessage = 'Deposit successful';
          this.errorMessage = '';
        }
      },
      error: (error) => {
        // Standard error handling for HTTP status codes
        if (error.status === 400) {
          this.errorMessage = 'Invalid account number. Please enter a valid account number.';
        } else if (error.status === 404) {
          this.errorMessage = 'Account not found. Please enter a valid account number.';
        } else if (error.status === 500) {
          this.errorMessage = 'Internal server error. Please try again later.';
        } else {
          this.errorMessage = 'Deposit failed. Please try again.';
        }
        this.successMessage = '';
      }
    });
  }
}
