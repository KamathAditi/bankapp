import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountExistenceComponent } from './accountexistence.component';

describe('AccountexistenceComponent', () => {
  let component: AccountExistenceComponent;
  let fixture: ComponentFixture<AccountExistenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccountExistenceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountExistenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
