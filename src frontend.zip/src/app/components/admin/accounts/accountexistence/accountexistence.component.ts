import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AccountService } from '../../../../services/account.service';

@Component({
  selector: 'app-account-existence',
  imports:[FormsModule,CommonModule,RouterModule],
  templateUrl: './accountexistence.component.html',
  styleUrls: ['./accountexistence.component.css']
})
export class AccountExistenceComponent {
  accountNumber: string | undefined; // Account number input
  accountExists: boolean | null = null; // Boolean result of account existence check
  errorMessage: string = ''; // Error message in case of failure

  constructor(private accountService: AccountService) {}

  // Method to check if the account exists
  checkIfAccountExists(): void {
    if (this.accountNumber) {
      this.accountService.existsAccount(this.accountNumber).subscribe(
        (data) => {
          this.accountExists = data;  // True if the account exists, false otherwise
          this.errorMessage = ''; // Clear error message if request is successful
        },
        (error) => {
          this.errorMessage = 'Error checking account existence. Please try again.';
          console.error(error);
        }
      );
    } else {
      this.errorMessage = 'Please enter a valid account number.';
    }
  }
}
