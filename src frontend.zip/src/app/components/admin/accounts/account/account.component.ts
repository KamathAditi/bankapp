import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-account', // This is the selector for the home page component
  templateUrl: './account.component.html', // Template for home page
  styleUrls: ['./account.component.css'] ,
  imports : [CommonModule]
})
export class AccountComponent {

  options:boolean = false;

  navigateToAccountList() {
    this.router.navigate(['admin/accountlist']);
  }

  navigateToAccountUpdate() {
    this.router.navigate(['admin/accountupdate']);
  }

  navigateToAccountDetails() {
    this.router.navigate(['admin/accountdetails']);
  }
  
  navigateToAccountCreate() {
    this.router.navigate(['admin/accountcreate']);
  }
  navigateToAccountBalance() {
    this.router.navigate(['admin/accountbalance']);
  }
  navigateToAccountExistence() {
    this.router.navigate(['admin/accountexistence']);
  }
  navigateToAccountAction() {
    this.router.navigate(['admin/accountaction']);
  }

  constructor(private router: Router) { }

  // Navigate to the account options page
  goToAccountOptions() {
    this.options = !this.options;
  }
}
