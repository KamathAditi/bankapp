import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Accountresponsedto } from '../../../../model/admin/models/accountresponsedto';
import { AccountService } from '../../../../services/account.service';

@Component({
  selector: 'app-account-list',
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './accountlist.component.html',
  styleUrls: ['./accountlist.component.css'],
})
export class AccountListComponent implements OnInit {

  accounts: Accountresponsedto[] = [];
  customerId: number | undefined;
  accountNumber: string | undefined;
  errorMessage: string = '';
  successMessage: string = '';

  showCustomerIdSearch = false; // Controls visibility of Customer ID search
  showAccountNumberSearch = false; // Controls visibility of Account Number search

  constructor(private accountService: AccountService, private router: Router) {}

  ngOnInit(): void {
    this.listAllAccounts(); // Initially show all accounts
  }

  // Reset messages before each action
  resetMessages(): void {
    this.successMessage = '';
    this.errorMessage = '';
  }

  // Fetch all accounts
  listAllAccounts(): void {
    this.resetMessages(); // Reset messages before making the request
    this.accountService.getAllAccounts().subscribe(
      (data) => {
        this.accounts = data;
        this.successMessage = 'Accounts loaded successfully';
        this.showCustomerIdSearch = false;
        this.showAccountNumberSearch = false;
      },
      (error) => {
        this.errorMessage = 'Error loading accounts';
        console.error(error);
      }
    );
  }

  // Fetch accounts by Customer ID
  listAccountsByCustomerId(): void {
    this.resetMessages(); // Reset messages before making the request
    this.accounts = []; // Clear the current accounts list when "List Accounts by Customer ID" is clicked

    if (this.customerId) {
      this.accountService.getAccountsByCustomerIds(this.customerId).subscribe(
        (data) => {
          this.accounts = data;
          if (this.accounts.length === 0) {
            this.errorMessage = 'No accounts found for this Customer ID';
          } else {
            this.successMessage = 'Accounts loaded by Customer ID';
          }
        },
        (error) => {
          this.errorMessage = 'Please enter a valid Customer ID';
          console.error(error);
        }
      );
    } else {
      this.errorMessage = 'Please enter a valid Customer ID';
    }
  }

  // Fetch account by Account Number
  listAccountsByAccountNumber(): void {
    this.resetMessages(); // Reset messages before making the request
    this.accounts = []; // Clear the current accounts list

    if (this.accountNumber) {
      this.accountService.getAccountsByAccountNumbers(this.accountNumber).subscribe(
        (data) => {
          this.accounts = [data]; // Assuming API returns a single account
          if (this.accounts.length === 0) {
            this.errorMessage = 'No account found for this Account Number';
          } else {
            this.successMessage = 'Account loaded by Account Number';
          }
        },
        (error) => {
          this.errorMessage = 'Please enter a valid Account Number';
          console.error(error);
        }
      );
    } else {
      this.errorMessage = 'Please enter a valid Account Number';
    }
  }

  // Navigate to account details
  navigateToAccountDetails(accountNumber: string): void {
    this.router.navigate([`/accountdetails/${accountNumber}`]);
  }

  // Navigate to account update
  navigateToAccountUpdate(accountNumber: string): void {
    this.router.navigate([`/accountupdate/${accountNumber}`]);
  }

  // Delete account
  deleteAccount(accountNumber: string): void {
    this.accountService.deleteAccount(accountNumber).subscribe(
      () => {
        this.accounts = this.accounts.filter((account) => account.accountNumber !== accountNumber);
        this.successMessage = 'Account deleted successfully';
      },
      (error) => {
        this.errorMessage = 'Error deleting account';
        console.error(error);
      }
    );
  }
  freezeAccount(accountNumber: string): void {
    this.accountService.freezeAccount(accountNumber).subscribe(
      (response) => {
        console.log("nige")
        this.successMessage = 'Account frozen successfully';
        this.errorMessage = '';
        this.updateAccountStatus(accountNumber, 'Frozen'); // Update account status in the list
      },
      (error) => {
        this.successMessage = '';
        if (error.status === 404) {
          this.errorMessage = 'Account not found';
        } else if (error.status === 400) {
          this.errorMessage = 'Invalid account number';
        } else {
          this.errorMessage = 'Failed to freeze account';
        }
      }
    );
  }

  unfreezeAccount(accountNumber: string): void {
    this.accountService.unfreezeAccount(accountNumber).subscribe(
      (response) => {
        this.successMessage = 'Account unfrozen successfully';
        this.errorMessage = '';
        this.updateAccountStatus(accountNumber, 'Active'); // Update account status in the list
      },
      (error) => {
        this.successMessage = '';
        if (error.status === 404) {
          this.errorMessage = 'Account not found';
        } else if (error.status === 400) {
          this.errorMessage = 'Invalid account number';
        } else {
          this.errorMessage = 'Failed to unfreeze account';
        }
      }
    );
  }
  updateAccountStatus(accountNumber: string, newStatus: string): void {
    const account = this.accounts.find(acc => acc.accountNumber === accountNumber);
    if (account) {
      account.status = newStatus; // Update the status of the account
    }
  }

  // Toggle visibility for search by Customer ID
  toggleCustomerIdSearch(): void {
    this.resetMessages(); // Reset messages when switching search options
    this.showCustomerIdSearch = true;
    this.showAccountNumberSearch = false; // Hide account number search
    this.accounts = []; // Clear the previously listed accounts only when the "List Accounts by Customer ID" button is clicked
  }

  // Toggle visibility for search by Account Number
  toggleAccountNumberSearch(): void {
    this.resetMessages(); // Reset messages when switching search options
    this.showAccountNumberSearch = true;
    this.showCustomerIdSearch = false; // Hide customer ID search
    this.accounts = []; // Clear the previously listed accounts only when the "List Accounts by Account Number" button is clicked
  }
}
