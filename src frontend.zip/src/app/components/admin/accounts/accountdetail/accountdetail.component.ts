import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from '../../../../services/account.service';
import { CustomerResponseDTO } from '../../../../model/admin/models/customerresponsedto';
import { CommonModule } from '@angular/common';
  // Update the path accordingly

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-account-details',
  templateUrl: './accountdetail.component.html',
  styleUrls: ['./accountdetail.component.css'],
})
export class AccountDetailComponent implements OnInit {
  accountNumber: string | undefined;  // The account number fetched from the URL
  customerDetails: CustomerResponseDTO | null = null;  // The customer details fetched from the backend
  errorMessage: string = '';
  loading: boolean = true;  // To show a loading state while the API is being called

  constructor(
    private accountService: AccountService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      this.accountNumber = params['accountNumber'];  // Get the account number from the URL
      if (this.accountNumber) {
        this.getCustomerDetails(this.accountNumber);  // Fetch customer details based on the account number
      }
    });
  }

  // Fetch customer details by account number
  getCustomerDetails(accountNumber: string): void {
    this.loading = true;
    this.accountService.getAccountHolder(accountNumber).subscribe(
      (response) => {
        this.customerDetails = response;  // Store the fetched customer details
        this.loading = false;  // Set loading to false once the data is fetched
      },
      (error) => {
        console.error('Error fetching customer details:', error);
        this.errorMessage = 'Error fetching customer details';
        this.loading = false;
      }
    );
  }

  // Navigate back to account list page
  goBack(): void {
    this.router.navigate(['admin/accountlist']);  // Navigate back to the account list page
  }
}
