import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AccountService } from '../../../../services/account.service';

@Component({
  selector: 'app-account-action',
  imports:[FormsModule,CommonModule,RouterModule],
  templateUrl: './accountaction.component.html',
  styleUrls: ['./accountaction.component.css']
})
export class AccountActionComponent implements OnInit {

  accountNumber!: string;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private accountService: AccountService, private router: Router) { }

  ngOnInit(): void {
    // You can load initial data if required
  }

  // Freeze account functionality
  freezeAccount(): void {
    if (this.accountNumber) {
      this.accountService.freezeAccount(this.accountNumber).subscribe(
        (response) => {
          this.successMessage = response;  // ✅ Shows "Account frozen"
          this.errorMessage = '';
        },
        (error) => {
          this.successMessage = '';
          if (error.status === 404) {
            this.errorMessage = 'Account not found';
          } else if (error.status === 400) {
            this.errorMessage = 'Invalid account number';
          } else {
            this.errorMessage = 'Failed to freeze account';
          }
        }
      );
    } else {
      this.errorMessage = 'Please enter a valid Account Number';
      this.successMessage = '';
    }
  }
  
  
  unfreezeAccount(): void {
    if (this.accountNumber) {
      this.accountService.unfreezeAccount(this.accountNumber).subscribe(
        (response) => {
          this.successMessage = response;  // ✅ Shows "Account unfrozen"
          this.errorMessage = '';
        },
        (error) => {
          this.successMessage = '';
          if (error.status === 404) {
            this.errorMessage = 'Account not found';
          } else if (error.status === 400) {
            this.errorMessage = 'Invalid account number';
          } else {
            this.errorMessage = 'Failed to unfreeze account';
          }
        }
      );
    } else {
      this.errorMessage = 'Please enter a valid Account Number';
      this.successMessage = '';
    }
  }
}  