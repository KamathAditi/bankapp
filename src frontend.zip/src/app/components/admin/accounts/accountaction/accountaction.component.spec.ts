import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountActionComponent } from './accountaction.component';

describe('AccountactionComponent', () => {
  let component: AccountActionComponent;
  let fixture: ComponentFixture<AccountActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccountActionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
