import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AccountService } from '../../../../services/account.service';

@Component({
  selector: 'app-account-balance', 
  imports:[FormsModule,CommonModule,RouterModule],
  templateUrl: './accountbalance.component.html',
  styleUrls: ['./accountbalance.component.css']
})
export class AccountBalanceComponent {
  accountNumber: string | undefined;  // Account number input by the user
  accountBalance: number | null = null;  // Holds the fetched balance
  errorMessage: string = '';  // Error message in case of failure

  constructor(private accountService: AccountService) {}

  // Method to get account balance
  getAccountBalance(): void {
    if (this.accountNumber) {
      this.accountService.getBalance(this.accountNumber).subscribe(
        (data) => {
          this.accountBalance = data;  // Set the account balance
          this.errorMessage = '';  // Clear any previous error message
        },
        (error) => {
          this.errorMessage = 'Error fetching account balance. Please check the account number.';
          console.error(error);
        }
      );
    } else {
      this.errorMessage = 'Please enter a valid account number.';
    }
  }
}
