// src/app/components/create-account/create-account.component.ts
import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Account } from '../../../../model/admin/models/account';
import { Accountrequestdto } from '../../../../model/admin/models/accountrequestdto';
import { Accountresponsedto } from '../../../../model/admin/models/accountresponsedto';
import { AccountService } from '../../../../services/account.service';

@Component({
  selector: 'app-create-account',
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './accountcreate.component.html',
  styleUrls: ['./accountcreate.component.css']
})
export class AccountCreateComponent {
  accountRequest: Accountrequestdto = new Accountrequestdto();
  account: Account = new Account();
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private accountService: AccountService, private router: Router) { }

  createAccount(): void {
    if (this.accountRequest) {
      this.accountService.createAccount(this.accountRequest).subscribe(
        (data: Accountresponsedto) => {
          this.successMessage = 'Account created successfully!';
          // Navigate to account details page or other pages after successful account creation
          this.router.navigate(['/accountdetails', data.accountNumber]);
        },
        (error) => {
          this.errorMessage = 'Error creating account. Please try again.';
          console.error(error);
        }
      );
    }

  }
}