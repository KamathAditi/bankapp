import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  imports : [CommonModule, RouterModule,FormsModule],
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {
  options: boolean = false;

  constructor(private router: Router) { }
  navigateToAddAdmin() {
    this.router.navigate(['admin/addadmin']);
  }
  navigateToCustomerList() {
    this.router.navigate(['admin/customerlist']);
  }
  navigateToGetCustomer() {
    this.router.navigate(['admin/getcustomer']);
  }
}
