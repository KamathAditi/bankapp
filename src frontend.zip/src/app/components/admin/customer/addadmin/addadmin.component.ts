import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CustomerRequestDTO } from '../../../../model/admin/models/customerrequestdto';
import { CustomerService } from '../../../../services/customer.service';

@Component({
  selector: 'app-addadmin',
  templateUrl: './addadmin.component.html',
  imports :[FormsModule,RouterModule,CommonModule]
})
export class AddAdminComponent {

  addAdminForm: FormGroup;
  successMessage = '';
  errorMessage = '';

  constructor(private fb: FormBuilder, private customerService: CustomerService) {
    this.addAdminForm = this.fb.group({
      name: ['', Validators.required],
      login: this.fb.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required]
      })
    });
  }

  onSubmit(): void {
    if (this.addAdminForm.invalid) return;

    const formData: CustomerRequestDTO = this.addAdminForm.value;

    this.customerService.addAdmins(formData).subscribe({
      next: (response) => {
        this.successMessage = 'Admin added successfully!';
        this.errorMessage = '';
        this.addAdminForm.reset();
      },
      error: (error) => {
        this.errorMessage = error?.error?.message || 'Something went wrong.';
        this.successMessage = '';
      }
    });
  }
}
