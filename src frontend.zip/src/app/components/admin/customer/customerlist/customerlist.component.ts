import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CustomerService } from '../../../../services/customer.service';

@Component({
  selector: 'app-customerlist',
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css'],
})
export class CustomerListComponent implements OnInit {
  customers: any[] = [];
  selectedCustomer: any = null;
  newFullName: string = '';
  newDob: string = '';
  newAddress: any = { doorNumber: '', streetName: '', city: '', state: '', pincode: '' };
  successMessage: string = '';
  errorMessage: string = '';


  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    this.loadCustomers();
    console.log("App component initialized");
  }

  loadCustomers(): void {
    this.customerService.getAllCustomers().subscribe({
      next: (data) => {
        this.customers = data;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load customers.';
        console.error(err);
      }
    });
  }

  // Open Update Customer Form
  openUpdateForm(customer: any) {
    this.selectedCustomer = customer;
    this.newFullName = customer.fullName;
    this.newDob = customer.dob;
    this.newAddress = { ...customer.address }; 
  }

  // Update customer name
  updateCustomerName() {
    if (this.selectedCustomer) {
      this.customerService.updateCustomerName(this.selectedCustomer.customerId, this.newFullName).subscribe(
        (response) => {
          this.selectedCustomer.fullName = this.newFullName;
          this.successMessage = 'Customer name updated successfully!';
          this.errorMessage = '';
        },
        (error) => {
          this.errorMessage = 'Failed to update customer name!';
          this.successMessage = '';
        }
      );
    } else {
      this.errorMessage = 'No customer selected!';
      this.successMessage = '';
    }
  }

  // Update customer DOB
  updateCustomerDob() {
    if (this.selectedCustomer) {
      this.customerService.updateCustomerDob(this.selectedCustomer.customerId, this.newDob).subscribe(
        (response) => {
          this.selectedCustomer.dob = this.newDob;
          this.successMessage = 'Customer DOB updated successfully!';
          this.errorMessage = '';
        },
        (error) => {
          this.errorMessage = 'Failed to update customer DOB!';
          this.successMessage = '';
        }
      );
    } else {
      this.errorMessage = 'No customer selected!';
      this.successMessage = '';
    }
  }

  // Update customer address
  updateCustomerAddress() {
    if (this.selectedCustomer && this.selectedCustomer.address) {
      const addressId = this.selectedCustomer.address.addressId;  // Ensure you have addressId here
      const newAddress = this.newAddress;  // This is the new address data
  
      // Assuming `this.selectedCustomer.customerId` is the customer you want to update
      this.customerService.updateCustomerAddresss(
        this.selectedCustomer.customerId, 
        addressId).subscribe(
        (response) => {
          this.selectedCustomer.address = { ...newAddress };  // Update the address after successful response
          this.successMessage = 'Customer address updated successfully!';
          this.errorMessage = '';
        },
        (error) => {
          this.errorMessage = 'Failed to update customer address!';
          this.successMessage = '';
        }
      );
    } else {
      this.errorMessage = 'No address or customer selected!';
      this.successMessage = '';
    }
  }
  

  // Delete customer logic
  deleteCustomer(customerId: number): void {
    this.customerService.deleteCustomer(customerId).subscribe(
      () => {
        this.customers = this.customers.filter((customer) => customer.customerId !== customerId);
        this.successMessage = 'Customer deleted successfully';
      },
      (error) => {
        this.errorMessage = 'Error deleting customer';
        console.error(error);
      }
    );
  }
}
