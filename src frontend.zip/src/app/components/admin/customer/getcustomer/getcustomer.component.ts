import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CustomerResponseDTO } from '../../../../model/admin/models/customerresponsedto';
import { CustomerService } from '../../../../services/customer.service';

@Component({
  selector: 'app-get-customer',
  templateUrl: './getcustomer.component.html',
  imports : [CommonModule, RouterModule,FormsModule],
  styleUrls: ['./getcustomer.component.css']
})
export class GetCustomerComponent implements OnInit {
  customers: CustomerResponseDTO[] = [];
  searchText: string = '';
  errorMessage: string = '';
  successMessage: string = '';
  activeSearchOption: string = ''; // Track the active search option

  constructor(private customerService: CustomerService) { }
  hasSearched: boolean = false;

  ngOnInit(): void {
    // Optionally, you can load initial data or any other logic here.
  }
  setActiveSearchOption(option: string): void {
    this.activeSearchOption = option;
    this.searchText = '';             // Clear search input
    this.successMessage = '';         // Clear success message
    this.errorMessage = '';           // Clear error message
    this.customers = [];              // Clear previously displayed results
  }

  // Search by ID
  searchById(): void {
    this.successMessage = '';  // Clear previous success message
    this.errorMessage = '';  
    const customerId = parseInt(this.searchText, 10);
    if (!isNaN(customerId)) {
      this.customerService.getCustomerByIds(customerId).subscribe(
        (response) => {
          this.customers = [response];  // We expect a single customer as the response
          this.successMessage = 'Customer found!';
        },
        (error) => {
          this.errorMessage = 'Customer not found.';
          console.error(error);
        }
      );
    } else {
      this.errorMessage = 'Invalid Customer ID.';
    }
  }

  // Search by Name
  searchByName(): void {
    this.successMessage = '';  // Clear previous success message
    this.errorMessage = '';  
    this.customerService.getCustomerByNames(this.searchText).subscribe(
      (response) => {
        this.customers = response;
        this.successMessage = `${response.length} customer(s) found`;
      },
      (error) => {
        this.errorMessage = 'No customers found with the given name.';
        console.error(error);
      }
    );
  }

  // Search by Date of Birth
  searchByDob(): void {
    this.successMessage = '';  // Clear previous success message
    this.errorMessage = '';  
    this.customerService.getCustomerByDobs(this.searchText).subscribe(
      (response) => {
        this.customers = response;
        this.successMessage = `${response.length} customer(s) found`;
      },
      (error) => {
        this.errorMessage = 'No customers found with the given date of birth.';
        console.error(error);
      }
    );
  }

  // Search by Email
  searchByEmail(): void {
    this.successMessage = '';  // Clear previous success message
    this.errorMessage = '';  
    this.customerService.getCustomerByEmails(this.searchText).subscribe(
      (response) => {
        this.customers = [response];  // We expect a single customer as the response
        this.successMessage = 'Customer found!';
      },
      (error) => {
        this.errorMessage = 'No customer found with the given email.';
        console.error(error);
      }
    );
  }

  
}
