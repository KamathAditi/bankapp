import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { CustomerRequestDto } from '../../model/Customer/customer-request-dto';
import { LoginRequestDto } from '../../model/login/login-request-dto';
import { AddressDto } from '../../model/address/address-dto';

@Component({
  selector: 'app-register',
  imports: [CommonModule, FormsModule, ReactiveFormsModule,],
  standalone: true,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  currentStep: number = 1;
  successMessage: string = '';
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) { }

  customerRequestDto: CustomerRequestDto = new CustomerRequestDto();
  registrationForm!: FormGroup;
  errorMessage!: string;

  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      contact: this.createContact(),
      login: this.createLogin(),
      addresses: this.fb.array([this.createAddress()])
    });
  }

  // Create a new address FormGroup
  createAddress() {
    return this.fb.group({
      doorNumber: ['', Validators.required],
      streetName: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.pattern(/^\d{6}$/)]]
    });
  }

  // Add another address to the form
  addAddress() {
    const addresses = this.registrationForm.get('addresses') as FormArray;
    if (addresses.length < 2) {
      addresses.push(this.createAddress());
    }
  }

  get addressesControls() {
    return (this.registrationForm.get('addresses') as FormArray).controls;
  }

  createContact() {
    return this.fb.group({
      fullName: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      dateOfBirth: ['', Validators.required]
    }, { validator: this.validDate })
  }

  validDate(group: AbstractControl): { [key: string]: boolean } | null {
    const dobValue = group.get('dateOfBirth')?.value;
    if (!dobValue) return null;

    const dob = new Date(dobValue);
    const today = new Date();
    const minAgeDate = new Date(today.getFullYear() - 16, today.getMonth(), today.getDate());

    if (dob > minAgeDate) {
      group.get('dateOfBirth')?.setErrors({ underAge: true });
      return { underAge: true };
    }

    return null;
  }


  createLogin() {
    return this.fb.group({
      email: ['', [Validators.required, this.strictEmailValidator]],
      password: ['', [
        Validators.required,
        Validators.minLength(8), 
        Validators.maxLength(20),
        Validators.pattern('.*[a-z].*'),
        Validators.pattern('.*[A-Z].*'),
        Validators.pattern('.*\\d.*'),
        Validators.pattern('.*[!@#$%^&*(),.?":{}|<>].*'),
      ],],
      confirmPassword: ['', Validators.required],
    }, { validator: this.matchPassword });
  }
  
  strictEmailValidator(control: AbstractControl): ValidationErrors | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailPattern.test(control.value) ? null : { validEmail: true };
  }

  matchPassword(group: AbstractControl): { [key: string]: boolean } | null {
    const password = group.get('password')?.value;
    const confirmPassword = group.get('confirmPassword')?.value;

    if (password && confirmPassword && password !== confirmPassword) {
      group.get('confirmPassword')?.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }

    return null;
  }


  // Move to next step
  goToNextStep(): void {
    if (this.currentStep === 1 && this.registrationForm.get('login')?.valid) {
      this.currentStep = 2;
    } else if (this.currentStep === 2 && this.registrationForm.get('contact')?.valid) {
      this.currentStep = 3;
    }
  }


  goToPreviousStep(): void {
    if (this.currentStep === 3) {
      this.currentStep = 2;
    } else if (this.currentStep === 2) {
      this.currentStep = 1;
    }
  }

  // Submit form
  onSubmit(): void {
    this.customerRequestDto = this.mapFormToDto(this.registrationForm)
    if (this.registrationForm.valid) {
      this.authService.register(this.customerRequestDto).subscribe(
        (response) => {
          // If the register is successful, we redirect to login
          if (response) {
            this.successMessage = "Registration Successful! Redirecting to login...";
          
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        }
      },
        (error) => {
          if (error.status === 400) {
            this.errorMessage = error.error.message;
          } else {
            this.errorMessage = "Unknow error occured!!";
          }
          console.error('Register failed:', error);
        }
      );
    }

    console.log(this.registrationForm.value);
  }

  onTextInput(event: any, controlName: string): void { 
    const inputValue = event.target.value;
    const noSpecialChars = inputValue.replace(/[^a-zA-Z ]/g, '');  
    event.target.value = noSpecialChars;
    this.registrationForm.get(controlName)?.setValue(noSpecialChars);
  }

  // Map form values to CustomerRequestDto
  mapFormToDto(registrationForm: FormGroup): CustomerRequestDto {
  const formValue = registrationForm.value; 

  const customerRequestDto = new CustomerRequestDto();
  customerRequestDto.fullName = formValue.contact.fullName;
  customerRequestDto.contactNumber = formValue.contact.contactNumber;
  customerRequestDto.dateOfBirth = new Date(formValue.contact.dateOfBirth);  // Parse date as needed

  // Map login object
  const loginDto = new LoginRequestDto();
  loginDto.email = formValue.login.email;
  loginDto.password = formValue.login.password;
  customerRequestDto.login = loginDto;

  // Map addresses
  const addressDtos: AddressDto[] = formValue.addresses.map((address: any) => {
    const addressDto = new AddressDto();
    addressDto.doorNumber = address.doorNumber;
    addressDto.streetName = address.streetName;
    addressDto.city = address.city;
    addressDto.state = address.state;
    addressDto.pincode = address.pincode;
    return addressDto;
  });
  customerRequestDto.addresses = addressDtos;

  return customerRequestDto;
  }
}
