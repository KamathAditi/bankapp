import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AccountService } from '../../services/account.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-delete-account',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './delete-account.component.html',
  styleUrl: './delete-account.component.css'
})
export class DeleteAccountComponent {
@Input() accountNumber: string | null | undefined = null;
  @Output() close = new EventEmitter<void>();

  isOpen = true;
  isDeleting = false;
  errorMessage = '';
  hasBalance = false;
  accountBalance = 0;
  isForceDeleting = false;

  constructor(
    private accountService: AccountService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (this.accountNumber) {
      this.checkAccountBalance();
    }
  }

  checkAccountBalance(): void {
    if (!this.accountNumber) return;

    this.accountService.getAccountDetails(this.accountNumber).subscribe({
      next: (account) => {
        this.accountBalance = account.balance;
        this.hasBalance = account.balance > 0;
      },
      error: (err) => {
        console.error('Error checking account balance', err);
        this.errorMessage = 'Could not verify account balance. Please try again.';
      }
    });
  }

  deleteAccount(): void {
    if (!this.accountNumber || this.hasBalance || this.isDeleting) return;

    this.isDeleting = true;
    this.errorMessage = '';

    this.accountService.deleteAccount(this.accountNumber).subscribe({
      next: () => {
        this.isDeleting = false;
        // Navigate back to dashboard after successful deletion
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        console.error('Error deleting account', err);
        this.errorMessage = 'Failed to close the account. Please try again later.';
        this.isDeleting = false;
      }
    });
  }

  deleteAccountAnyways(): void {
  if (!this.accountNumber) return;

  this.isForceDeleting = true;
  this.errorMessage = '';

  this.accountService.deleteAccount(this.accountNumber).subscribe({
    next: () => {
      this.isForceDeleting = false;
      this.router.navigate(['/dashboard']);
    },
    error: (err) => {
      console.error('Error deleting account', err);
      this.errorMessage = 'Failed to close the account. Please try again later.';
      this.isForceDeleting = false;
    }
  });
}


  onClose(): void {
    this.isOpen = false;
    // Use setTimeout to allow the closing animation to complete
    setTimeout(() => {
      this.close.emit();
    }, 200);
  }
}
