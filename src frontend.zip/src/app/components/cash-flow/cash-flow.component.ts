import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Statement } from '../../model/statement/statement';
import { AccountService } from '../../services/account.service';
import { CustomerService } from '../../services/customer.service';
import { CustomerResponseDto } from '../../model/Customer/customer-response-dto';

@Component({
  selector: 'app-cash-flow',
  imports: [CommonModule],
  templateUrl: './cash-flow.component.html',
  styleUrl: './cash-flow.component.css'
})
export class CashFlowComponent {
  customerData: CustomerResponseDto | null = null;
  cashFlowData: Statement | null = null;
  isLoading = true;
  customerId: number | null = null;

  constructor(
    private accountService: AccountService, 
    private customerService: CustomerService
  ) {}

  ngOnInit(): void {
    this.loadCustomerData();
  }

  private loadCustomerData(): void {
    this.isLoading = true;
    this.customerService.getCustomerDetails().subscribe({
      next: (data) => {
        this.customerData = data;
        this.customerId = this.customerData.customerId;
        // Load cashflow data after getting customer ID
        if (this.customerId) {
          this.loadCashflowData(this.customerId);
        }
      },
      error: (error) => {
        console.error('Error loading customer data:', error);
        this.isLoading = false;
      }
    });
  }

  private loadCashflowData(customerId: number): void {
    this.accountService.getStatement(customerId).subscribe({
      next: (data) => {
        this.cashFlowData = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching cashflow data:', err);
        this.isLoading = false;
      }
    });
  }

  formatCurrency(value: string | undefined | null): string {
    if (!value) return '0.00 $';
    // Remove any existing currency symbols and spaces
    const cleanValue = value.replace(/[^0-9.-]/g, '');
    // Parse the string to a number
    const numValue = parseFloat(cleanValue);
    if (isNaN(numValue)) return '0.00 $';
    
    // Format the number with 2 decimal places
    const formattedValue = numValue.toFixed(2);
    // Split into whole and decimal parts
    const [whole, decimal] = formattedValue.split('.');
    // Add thousand separators to whole part
    const formattedWhole = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    
    return `${formattedWhole}.${decimal} $`;
  }

  getIncomePercentage(): number {
    if (!this.cashFlowData?.totalCashFlow || !this.cashFlowData?.income) return 0;
    const total = parseFloat(this.cashFlowData.totalCashFlow.replace(/[^0-9.-]/g, ''));
    const income = parseFloat(this.cashFlowData.income.replace(/[^0-9.-]/g, ''));
    return total === 0 ? 0 : Math.round((income / total) * 100);
  }

  getExpensePercentage(): number {
    if (!this.cashFlowData?.totalCashFlow || !this.cashFlowData?.expense) return 0;
    const total = parseFloat(this.cashFlowData.totalCashFlow.replace(/[^0-9.-]/g, ''));
    const expense = parseFloat(this.cashFlowData.expense.replace(/[^0-9.-]/g, ''));
    return total === 0 ? 0 : Math.round((expense / total) * 100);
  }
}
