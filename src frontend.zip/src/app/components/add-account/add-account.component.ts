import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccountRequest } from '../../model/account/account-request';
import { CustomerResponseDto } from '../../model/Customer/customer-response-dto';
import { AccountService } from '../../services/account.service';
import { CustomerService } from '../../services/customer.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-account',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  standalone: true,
  templateUrl: './add-account.component.html',
  styleUrl: './add-account.component.css'
})
export class AddAccountComponent {
addAccountForm!: FormGroup;  // Declare FormGroup
  customerId!: number;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,  // Inject FormBuilder
    private accountService: AccountService,
    private router: Router,
    private customerService: CustomerService
  ) { }

  ngOnInit() {

    this.addAccountForm = this.fb.group({
      accountType: ['', Validators.required],
      balance: [0, [Validators.required, Validators.min(100), Validators.pattern('^[0-9]*$')]]
    });

    this.customerService.getCustomerDetails().subscribe(
      {
        next: (customer: CustomerResponseDto) => {
          this.customerId = customer.customerId;
        },
        error: () => {
          this.errorMessage = 'Failed to find customer';
        }
      }

    );
  }

   addAccount() {
    if (this.addAccountForm.valid) {
      // Prepare the new account object
      const newAccount: AccountRequest = {
        customerId: this.customerId,
        accountType: this.addAccountForm.value.accountType,
        balance: this.addAccountForm.value.balance
      };
      console.log(newAccount);
      this.accountService.addAccount(newAccount).subscribe({
        next: (response) => {
          console.log('Account added successfully', response);
          alert('Account created successfully!');
          this.router.navigate(['/dashboard']);  
        },
        error: (error) => {
          console.error('Error adding account', error);
          alert('There was an error creating the account.');
        }
      });
    } else {
      alert('Please fill in all fields correctly.');
    }
  }

  get accountType() {
    return this.addAccountForm.get('accountType');
  }

  get balance() {
    return this.addAccountForm.get('balance');
  }

}
