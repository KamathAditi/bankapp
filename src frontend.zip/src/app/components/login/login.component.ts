import { Component } from '@angular/core';
import {AuthService} from '../../services/auth.service';
import {Router} from '@angular/router';
import { LoginRequestDto } from '../../model/login/login-request-dto';
import {FormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  errorMessage!: string;

  constructor(private authService: AuthService, private router:Router) {}

  loginRequestDto:LoginRequestDto = new LoginRequestDto();

  onSubmit(): void {
    this.authService.login(this.loginRequestDto).subscribe(
      (response) => {
        // If the login is successful, we store the token
        if (response && response.token) {
          this.authService.saveToken(response.token);
          console.log('Login successful');
          if(this.authService.getRole() === "ADMIN")
            this.router.navigate(['/admin']);
          else
          if(this.authService.getRole() === "CUSTOMER"){
            
            this.router.navigate(['/dashboard'])

          }
        }
      },
      (error) => {
        this.authService.removeToken;
        localStorage.clear
        if (error.status === 400) {
          this.errorMessage = error.error.message;
        } else {
          this.errorMessage = "Unknow error occured!!";
        }
        console.error('Login failed:', error);
      }
    );
  }

}
