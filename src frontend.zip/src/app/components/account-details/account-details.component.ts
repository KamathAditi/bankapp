import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import { Account } from '../../model/account/account';
import { AccountService } from '../../services/account.service';
import { CommonModule } from '@angular/common';
import { AccountTransactionsComponent } from "../account-transactions/account-transactions.component";
import { DeleteAccountComponent } from "../delete-account/delete-account.component";

@Component({
  selector: 'app-account-details',
  imports: [CommonModule, AccountTransactionsComponent, DeleteAccountComponent],
  standalone: true,
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.css'
})
export class AccountDetailsComponent {
account: Account | null = null;
  accountNumber: string | null = null;
  loading = true;
  error = false;
  errorMessage = '';
  showDeleteModal = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private accountService: AccountService
  ) {
    // Try to get account number from route params first
    this.route.paramMap.subscribe(params => {
      const accNumber = params.get('accountNumber');
      if (accNumber) {
        this.accountNumber = accNumber;
      } else {
        // Fall back to router state if not in route params
        const navigation = this.router.getCurrentNavigation();
        this.accountNumber = navigation?.extras.state?.['accountNumber'] ?? null;
      }
    });
  }

  ngOnInit(): void {
    this.fetchAccountDetails();
  }

  fetchAccountDetails(): void {
    if (!this.accountNumber) {
      this.error = true;
      this.errorMessage = 'No account number provided';
      this.loading = false;
      return;
    }

    this.loading = true;
    this.error = false;
    
    this.accountService.getAccountDetails(this.accountNumber).subscribe({
      next: (data: Account) => {
        this.account = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error fetching account details', err);
        this.error = true;
        this.errorMessage = 'Failed to load account details. Please try again later.';
        this.loading = false;
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  openDeleteModal(): void {
    this.showDeleteModal = true;
  }

  closeDeleteModal(): void {
    this.showDeleteModal = false;
    // Refresh account details after modal closes (in case delete was cancelled)
    this.fetchAccountDetails();
  }

  // Helper method for account type display
  getAccountTypeLabel(type: string): string {
    switch (type) {
      case 'SAVINGS': return 'Savings Account';
      case 'CURRENT': return 'Current Account';
      case 'FIXED_DEPOSIT': return 'Fixed Deposit';
      default: return type;
    }
  }
}
