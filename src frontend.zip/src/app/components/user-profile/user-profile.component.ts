import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CustomerResponseDto } from '../../model/Customer/customer-response-dto';
import { CustomerService } from '../../services/customer.service';
import { AddressRequestDto } from '../../model/address/address-request-dto';
import { Router } from '@angular/router';
import { AddressDto } from '../../model/address/address-dto';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './user-profile.component.html',
  styleUrl: './user-profile.component.css'
})
export class UserProfileComponent {
   customer!: CustomerResponseDto;
  editForm!: FormGroup;
  addressForm!: FormArray;
  addresses!: AddressDto[]; // Changed from AddressRequestDto[] to AddressDto[]
  editingAddressId: string | null = null; // Track which address is being edited
  isLoading = true;
  errorMessage = '';
  successMessage = '';
  isEditing: boolean = false;

  constructor(
    private customerService: CustomerService,
    private fb: FormBuilder,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.loadCustomer();
  }

  initAddressForms(): void {
    // Initialize FormArray with one FormGroup for each address
    this.addressForm = this.fb.array(
      this.addresses.map((address) => this.createAddressForm(address))
    );
  }

  createAddressForm(address: AddressDto | AddressRequestDto): FormGroup { // Accept both types since we only use common properties
    return this.fb.group({
      doorNumber: [
        address.doorNumber, 
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(10)
        ]
      ],
      streetName: [
        address.streetName, 
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(100)
        ]
      ],
      city: [
        address.city, 
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(50),
          Validators.pattern(/^[a-zA-Z\s]+$/)
        ]
      ],
      state: [
        address.state, 
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(50),
          Validators.pattern(/^[a-zA-Z\s]+$/)
        ]
      ],
      pincode: [
        address.pincode, 
        [
          Validators.required,
          Validators.pattern(/^[0-9]{6}$/)
        ]
      ],
    });
  }

  enableAddressEdit(address: AddressDto): void {
    this.editingAddressId = address.addressId;
    
    // Find the form group for the selected address and patch the values
    const addressIndex = this.addresses.findIndex(addr => addr.addressId === address.addressId);
    if (addressIndex !== -1) {
      const addressFormGroup = this.addressForm.at(addressIndex) as FormGroup;
      addressFormGroup.patchValue({
        doorNumber: address.doorNumber,
        streetName: address.streetName,
        city: address.city,
        state: address.state,
        pincode: address.pincode,
      });
    }
  }

  cancelAddressEdit(): void {
    this.editingAddressId = null;
    // Reset the form to original values
    this.initAddressForms();
  }

  saveAddressChanges(address: AddressDto): void {
    const addressIndex = this.addresses.findIndex(addr => addr.addressId === address.addressId);
    if (addressIndex === -1) return;

    const addressFormGroup = this.addressForm.at(addressIndex) as FormGroup;
    
    if (addressFormGroup?.invalid) {
      // Mark all fields as touched to show validation errors
      Object.keys(addressFormGroup.controls).forEach(key => {
        addressFormGroup.get(key)?.markAsTouched();
      });
      return;
    }

    // Create updated address without including addressId in the request body
    const updatedAddress: AddressRequestDto = { // Explicitly type as AddressRequestDto for the API call
      doorNumber: addressFormGroup.value.doorNumber,
      streetName: addressFormGroup.value.streetName,
      city: addressFormGroup.value.city,
      state: addressFormGroup.value.state,
      pincode: addressFormGroup.value.pincode,
    };

    // Call the service to update the specific address (addressId sent as path variable)
    this.customerService.updateCustomerAddress(
      this.customer.customerId,
      address.addressId,
      updatedAddress
    ).subscribe({
      next: (updated) => {
        this.customer = updated;
        this.addresses = updated.addresses;
        this.successMessage = 'Address updated successfully!';
        this.editingAddressId = null;
        this.initAddressForms(); // Reinitialize forms with updated data
        this.clearMessagesAfterDelay();
      },
      error: () => {
        this.errorMessage = 'Failed to update address.';
        this.clearMessagesAfterDelay();
      },
    });
  }

  isAddressEditing(addressId: string): boolean {
    return this.editingAddressId === addressId;
  }

  getAddressFormGroup(index: number): FormGroup {
    return this.addressForm.at(index) as FormGroup;
  }

  get addressForms(): AbstractControl[] {
    return this.addressForm.controls;
  }

  loadCustomer(): void {
    this.isLoading = true;
    this.customerService.getCustomerDetails().subscribe({
      next: (data) => {
        this.customer = data;
        this.addresses = data.addresses;
        this.initForm();
        this.initAddressForms();
        this.isLoading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to load user profile.';
        this.isLoading = false;
      }
    });
  }

  initForm(): void {
    this.editForm = this.fb.group({
      fullName: [this.customer.fullName, [Validators.required, Validators.minLength(2)]],
      dateOfBirth: [this.customer.dateOfBirth, [Validators.required]],
    });
  }

  enableEdit() {
    this.isEditing = true
  }

  cancelEdit(): void {
    this.isEditing = false;
    this.editForm.patchValue({
      fullName: this.customer.fullName,
      dateOfBirth: this.customer.dateOfBirth
    });
    this.successMessage = '';
    this.errorMessage = '';
  }

  saveChanges(): void {
    if (this.editForm.invalid) return;
  }

  updateName(): void {
    const control = this.editForm.get('fullName');
    if (!control || control.invalid) return;

    const name = control.value;
    console.log(name);
    this.customerService.updateCustomerName(this.customer.customerId, name).subscribe({
      next: (updated) => {
        this.customer.fullName = updated.fullName;
        this.successMessage = 'Full name updated successfully!';
        this.clearMessagesAfterDelay();
      },
      error: () => {
        this.errorMessage = 'Failed to update full name.';
        this.clearMessagesAfterDelay();
      }
    });
  }

  updateDob(): void {
    const control = this.editForm.get('dateOfBirth');
    if (!control || control.invalid) return;

    const dob = control.value;
    this.customerService.updateCustomerDob(this.customer.customerId, dob).subscribe({
      next: (updated) => {
        this.customer.dateOfBirth = updated.dateOfBirth;
        this.successMessage = 'Date of Birth updated successfully!';
        this.clearMessagesAfterDelay();
      },
      error: () => {
        this.errorMessage = 'Failed to update Date of Birth.';
        this.clearMessagesAfterDelay();
      }
    });
  }

  deleteCustomer(): void {
    if (!confirm('Are you sure you want to delete your profile?')) return;

    this.customerService.deleteCustomer(this.customer.customerId).subscribe({
      next: () => {
        this.successMessage = 'Profile deleted successfully!';
        // You can route to logout or home here
      },
      error: () => {
        this.errorMessage = 'Failed to delete profile.';
        this.clearMessagesAfterDelay();
      }
    });
  }

  private clearMessagesAfterDelay(): void {
    setTimeout(() => {
      this.successMessage = '';
      this.errorMessage = '';
    }, 3000);
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}