import { Component } from '@angular/core';
import { Account } from '../../model/account/account';
import { AccountService } from '../../services/account.service';
import { CustomerService } from '../../services/customer.service';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-account-cards',
  imports: [CommonModule, RouterOutlet],
  templateUrl: './account-cards.component.html',
  styleUrl: './account-cards.component.css'
})
export class AccountCardsComponent {
accounts: Account[] = [];
  errorMessage: string = '';
  isLoading: boolean = true;
  selectedAccount: Account | null = null;


  constructor(
    private router:Router,
    private customerService: CustomerService,
    private accountService: AccountService
  ) {}
  
  ngOnInit(): void {
    this.customerService.getCustomerDetails().subscribe({
      next: (customer) => {
        const customerId = customer.customerId;
        this.accountService.getAccountsByCustomerId(customerId).subscribe({
          next: (data) => {
            this.accounts = data;
            this.isLoading = false;
          },
          error: () => {
            this.errorMessage = 'Failed to load accounts';
            this.isLoading = false;
          }
        });
      },
      error: () => {
        this.errorMessage = 'Failed to load customer info';
        this.isLoading = false;
      }
    });
  }

  goToAccountDetails(accountNumber: string): void {
    this.router.navigate([`/dashboard/account`], {state: {accountNumber: accountNumber}});
  }
  goToAddAccount() {
    this.router.navigate([`dashboard/add-account`]);
  }
}
