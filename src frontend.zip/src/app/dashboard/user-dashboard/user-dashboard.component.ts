import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { UserNavbarComponent } from "../../navbar/user-navbar/user-navbar.component";
import { AccountCardsComponent } from "../../components/account-cards/account-cards.component";
import { CashFlowComponent } from "../../components/cash-flow/cash-flow.component";
import { TransferComponent } from "../../components/transfer/transfer.component";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AccountService } from '../../services/account.service';


@Component({
  selector: 'app-user-dashboard',
  standalone:true,
  imports: [RouterOutlet,AccountCardsComponent, CashFlowComponent, TransferComponent],
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})
export class UserDashboardComponent {

}
