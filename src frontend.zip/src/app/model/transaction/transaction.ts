export class Transaction {
    transactionId!: string;
    transactionType!: string;
    timeStamp!: string;
    amount!: string;
    status!: string;
    senderAccountNumber!: string;
    receiverAccountNumber!: string;
    description!: string;
}
