import { AccountRequest } from './account-request';

describe('AccountRequest', () => {
  it('should create an instance', () => {
    expect(new AccountRequest()).toBeTruthy();
  });
});
