export interface Account {
    accountNumber: string;
    accountType: string;
    balance: number;
    createdAt: string;
    frozen: string;
}
