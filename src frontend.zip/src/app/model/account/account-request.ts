export interface AccountRequest {
    customerId: number;
    accountType: string;
    balance: number;
    
}
