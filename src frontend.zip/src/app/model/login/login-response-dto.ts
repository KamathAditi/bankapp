export class LoginResponseDto {
    email!:string;
    role!:string;
    token!:string;
}
