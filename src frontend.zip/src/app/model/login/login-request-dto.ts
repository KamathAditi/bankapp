export class LoginRequestDto {

    email!: string;
    password!: string;
    role!: string;
    
}
