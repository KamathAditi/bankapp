import { LoginRequestDto } from './login-request-dto';

describe('LoginRequestDto', () => {
  it('should create an instance', () => {
    expect(new LoginRequestDto()).toBeTruthy();
  });
});
