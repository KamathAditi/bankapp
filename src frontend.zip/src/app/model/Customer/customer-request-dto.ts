import {LoginRequestDto} from '../login/login-request-dto';
import {AddressDto} from '../address/address-dto';

export class CustomerRequestDto {

  fullName!:string;
  contactNumber!:string;
  dateOfBirth!:Date;
  login!:LoginRequestDto;
  addresses!:AddressDto[];

}
