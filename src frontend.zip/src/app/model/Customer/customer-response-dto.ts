import { Account } from "../account/account";
import { AddressDto } from "../address/address-dto";

export class CustomerResponseDto {
  customerId!: number;
  fullName!: string;
  contactNumber!: string;
  dateOfBirth!: string;
  email!: string;
  addresses!: AddressDto[];
  accounts!: Account[];
}
