import { CustomerResponseDto } from './customer-response-dto';

describe('CustomerResponseDto', () => {
  it('should create an instance', () => {
    expect(new CustomerResponseDto()).toBeTruthy();
  });
});
