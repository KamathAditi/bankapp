import { CustomerRequestDto } from './customer-request-dto';

describe('CustomerRequestDto', () => {
  it('should create an instance', () => {
    expect(new CustomerRequestDto()).toBeTruthy();
  });
});
