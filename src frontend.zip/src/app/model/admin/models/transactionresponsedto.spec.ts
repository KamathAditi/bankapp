import { Transactionresponsedto } from './transactionresponsedto';

describe('Transactionresponsedto', () => {
  it('should create an instance', () => {
    expect(new Transactionresponsedto()).toBeTruthy();
  });
});
