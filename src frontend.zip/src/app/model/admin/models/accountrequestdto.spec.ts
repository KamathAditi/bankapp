import { Accountrequestdto } from './accountrequestdto';

describe('Accountrequestdto', () => {
  it('should create an instance', () => {
    expect(new Accountrequestdto()).toBeTruthy();
  });
});
