// login.dto.ts

export class LoginDTO {
    email: string = '';
    password: string = '';
  
    constructor(init?: Partial<LoginDTO>) {
      Object.assign(this, init);
    }
  }
  