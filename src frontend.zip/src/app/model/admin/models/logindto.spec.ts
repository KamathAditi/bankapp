import { Logindto } from './logindto';

describe('Logindto', () => {
  it('should create an instance', () => {
    expect(new Logindto()).toBeTruthy();
  });
});
