// customer-request.dto.ts

import { LoginDTO } from './logindto'; // Import LoginDTO if it's in a separate file

export class CustomerRequestDTO {
  name: string = '';
  login: LoginDTO = new LoginDTO();

  constructor(init?: Partial<CustomerRequestDTO>) {
    Object.assign(this, init);
  }
}
