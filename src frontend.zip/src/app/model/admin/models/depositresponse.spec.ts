import { Depositresponse } from './depositresponse';

describe('Depositresponse', () => {
  it('should create an instance', () => {
    expect(new Depositresponse()).toBeTruthy();
  });
});
