export class TransactionResponseDTO {
    constructor(
      public transactionId: number,
      public transactionType: string,
      public amount: number,
      public status: string,
      public senderAccountNumber: number | null,
      public receiverAccountNumber: number | null,
      public timestamp: Date,
      public description: string
    ) {}
  }
  