import { Accountactionresponse } from './accountactionresponse';

describe('Accountactionresponse', () => {
  it('should create an instance', () => {
    expect(new Accountactionresponse()).toBeTruthy();
  });
});
