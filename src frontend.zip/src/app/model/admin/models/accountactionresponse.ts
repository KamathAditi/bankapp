export class AccountStatusResponse {
      public accountNumber!: string;
      public status!: string;
  
    isFrozen(): boolean {
      return this.status.toLowerCase().includes('frozen');
    }
  }
  