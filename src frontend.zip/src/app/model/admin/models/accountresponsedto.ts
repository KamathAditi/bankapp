export class Accountresponsedto {
    accountNumber: string = '';
  accountType: string = '';
  balance: number = 0;
  frozen!: string; 
  customerId: number = 0;
  fullName: string='';
  status!: string;
  

}