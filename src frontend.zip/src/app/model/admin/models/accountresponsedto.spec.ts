import { Accountresponsedto } from './accountresponsedto';

describe('Accountresponsedto', () => {
  it('should create an instance', () => {
    expect(new Accountresponsedto()).toBeTruthy();
  });
});
