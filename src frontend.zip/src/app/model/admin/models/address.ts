export class Address {
    doorNumber: string = '';  // Default empty string
    streetName: string = '';  // Default empty string
    city: string = '';  // Default empty string
    state: string = '';  // Default empty string
    pincode: string = '';  // Default empty string
  
    constructor(init?: Partial<Address>) {
      Object.assign(this, init);  // This will copy the values from `init` (if provided)
    }
  }
  