
import { Address } from './address'; 
export class CustomerResponseDTO {
  customerId!: number;
  fullName!: string;
  email!: string;
  contactNumber!: string;
  dateOfBirth!: string;
  address!: Address;

  constructor(init?: Partial<CustomerResponseDTO>) {
    Object.assign(this, init);
  }
}
