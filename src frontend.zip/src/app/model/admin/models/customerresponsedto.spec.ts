import { Customerresponsedto } from './customerresponsedto';

describe('Customerresponsedto', () => {
  it('should create an instance', () => {
    expect(new Customerresponsedto()).toBeTruthy();
  });
});
