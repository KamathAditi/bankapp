// src/app/models/account-request.dto.ts
export class Accountrequestdto {
    accountNumber: string = '';
    accountType: string = '';
    balance: number = 0;
    frozen: boolean = false; // Represents if the account is frozen
    customerId: number = 0;
  
  }
  