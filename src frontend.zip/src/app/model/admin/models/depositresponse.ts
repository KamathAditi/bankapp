export class DepositResponse {
    accountNumber: number;
    status: string;
  
    constructor(accountNumber: number, status: string) {
      this.accountNumber = accountNumber;
      this.status = status;
    }
  }
  