export class Account {
    accountNumber: string = '';  // Backend will generate this
    accountType: string = '';
    balance: number = 0;
    status: boolean = false;  // Default status (could be 'active', 'inactive', etc.)
    frozen!: string;  // Default frozen state
    customerId: number = 0;  // Customer that owns this account
    fullName:string='';
  
  }
  