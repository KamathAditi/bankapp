import { Customerrequestdto } from './customerrequestdto';

describe('Customerrequestdto', () => {
  it('should create an instance', () => {
    expect(new Customerrequestdto()).toBeTruthy();
  });
});
