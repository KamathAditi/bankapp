export class AddressRequestDto {

doorNumber!:string;
  streetName!:string;
  city!:string;
  state!:string;
  pincode!:string;
}
