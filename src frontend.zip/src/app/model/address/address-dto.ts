export class AddressDto {

  addressId!:string|any;
  doorNumber!:string;
  streetName!:string;
  city!:string;
  state!:string;
  pincode!:string;

}
