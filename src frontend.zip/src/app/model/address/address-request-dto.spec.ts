import { AddressRequestDto } from './address-request-dto';

describe('AddressRequestDto', () => {
  it('should create an instance', () => {
    expect(new AddressRequestDto()).toBeTruthy();
  });
});
