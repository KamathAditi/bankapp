import { AddressDto } from './address-dto';

describe('AddressDto', () => {
  it('should create an instance', () => {
    expect(new AddressDto()).toBeTruthy();
  });
});
