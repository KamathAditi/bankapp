import { Statement } from './statement';

describe('Statement', () => {
  it('should create an instance', () => {
    expect(new Statement()).toBeTruthy();
  });
});
