export class Statement {
    daily!: string;
  weekly!: string;
  monthly!: string;
  income!: string;
  expense!: string;
  totalCashFlow!: string;
}
