import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';


export const authGuard: CanActivateFn = (route, state) => {

  const authService = inject(AuthService); // Use Angular's inject function to get the AuthService instance
  const router = inject(Router); // Get the Router instance

  // Check if the user is logged in
  if (authService.isLoggedIn()) {
    return true; // Allow access to the route
  } else {
    router.navigate(['/login']);
    return false; // Prevent access to the route
  }

};