import { Component } from '@angular/core';
import { CustomerResponseDto } from '../../model/Customer/customer-response-dto';
import { AuthService } from '../../services/auth.service';
import { CustomerService } from '../../services/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-navbar',
  imports: [],
  standalone:true,
  templateUrl: './user-navbar.component.html',
  styleUrl: './user-navbar.component.css'
})
export class UserNavbarComponent {
   customerData: CustomerResponseDto | null = null;

  constructor(
    private authService: AuthService,
    private customerService: CustomerService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadCustomerData();
  }

  private loadCustomerData() {
    this.customerService.getCustomerDetails().subscribe({
      next: (data) => {
        this.customerData = data;
      },
      error: (error) => {
        console.error('Error loading customer data:', error);
      }
    });
  }

  getInitials(): string {
    if (!this.customerData) return '';
    return `${this.customerData.fullName?.[0]}`;
  }

  logout() {
    this.authService.logout();
    window.location.replace('/login');

  }
  goToDashboard() {
    this.router.navigate([`dashboard`],);
  }
  profile(){
    this.router.navigate([`dashboard/profile`],);
  }
}
